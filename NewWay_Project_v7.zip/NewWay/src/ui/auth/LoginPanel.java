package ui.auth;

import db.DBConnection;
import model.User;
import ui.MainFrame;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * LoginPanel — Teal + Orange theme. Animated hero with ONLY heading.
 * Login tab + Create Account tab. No password shown in hint cards.
 */
public class LoginPanel extends JPanel {

    // ── Color Theme: White + Purple + Orange ─────────────────────────────────
    static final Color WHITE       = Color.WHITE;
    static final Color TEAL        = new Color(108,  45, 180);   // Purple primary
    static final Color TEAL_DK     = new Color(80,   28, 140);   // Purple dark
    static final Color TEAL_LIGHT  = new Color(245, 238, 255);   // Purple tint
    static final Color ORANGE      = new Color(240, 100,  20);   // Orange accent
    static final Color CHARCOAL    = new Color(22,   20,  30);
    static final Color WARM_GRAY   = new Color(110, 105, 120);
    static final Color BORDER_CLR  = new Color(220, 210, 235);
    static final Color INPUT_BG    = new Color(252, 250, 255);
    static final Color BG_FORM     = Color.WHITE;
    static final Color DEEP_BG     = new Color(18,   8,  40);   // Deep purple-dark

    static final Font F_HERO   = new Font("Georgia",      Font.BOLD | Font.ITALIC, 54);
    static final Font F_TITLE  = new Font("Georgia",      Font.BOLD,               30);
    static final Font F_BODY   = new Font("Trebuchet MS", Font.PLAIN,               13);
    static final Font F_LABEL  = new Font("Trebuchet MS", Font.BOLD,                9);
    static final Font F_INPUT  = new Font("Trebuchet MS", Font.PLAIN,               14);
    static final Font F_BTN    = new Font("Trebuchet MS", Font.BOLD,                14);
    static final Font F_SMALL  = new Font("Trebuchet MS", Font.PLAIN,               11);

    private JTextField     loginEmail;
    private JPasswordField loginPass;
    private JLabel         loginMsg;
    private JButton        signInBtn;

    private JTextField     regName, regEmail, regPhone, regLocation;
    private JPasswordField regPass, regPass2;
    private JLabel         regMsg;

    private javax.swing.Timer animTimer;
    private double animTick = 0;
    private HeroPanel heroPanel;

    // Delivery-themed floats: food, clock, bike, map, rocket
    private final FoodFloat[] floats = {
        new FoodFloat("🍛", 0.16f, 0.28f, 112, new Color(160, 80, 220), 0.0f),
        new FoodFloat("⏱️", 0.74f, 0.22f,  82, new Color(240,100, 20),  1.2f),
        new FoodFloat("🏍️", 0.10f, 0.65f,  90, new Color(200, 60,240),  2.4f),
        new FoodFloat("🗺️", 0.78f, 0.66f,  98, new Color(255,150, 40),  0.8f),
        new FoodFloat("🍜", 0.47f, 0.12f,  68, new Color(130, 40,200),  1.8f),
        new FoodFloat("📊", 0.42f, 0.80f,  76, new Color(255,100, 50),  3.1f),
    };
    private final float[][] orbDefs = {
        {0.12f,0.22f,0.50f, 108, 45,180, 65, 0.70f},
        {0.80f,0.44f,0.45f, 240,100, 20, 55, 1.10f},
        {0.44f,0.86f,0.42f, 160, 40,220, 48, 0.90f},
        {0.70f,0.12f,0.35f, 200, 80,255, 42, 1.30f},
    };
    private final List<Spark> sparks = new ArrayList<>();
    private final Random rng = new Random(System.nanoTime());

    public LoginPanel() {
        setLayout(new GridLayout(1, 2, 0, 0));
        for (int i = 0; i < 50; i++) sparks.add(new Spark());
        heroPanel = buildHeroPanel();
        add(heroPanel);
        add(buildFormPanel());
        startAnimation();
    }

    private void startAnimation() {
        animTimer = new javax.swing.Timer(16, e -> {
            animTick += 0.016;
            for (Spark s : sparks) s.update();
            heroPanel.repaint();
        });
        animTimer.start();
    }

    // =====================================================================
    //  HERO PANEL — left side, delivery-theme icons + ONLY heading text
    // =====================================================================
    private HeroPanel buildHeroPanel() {
        HeroPanel panel = new HeroPanel();
        panel.setLayout(new BorderLayout());

        // Top brand bar
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 18));
        topBar.setOpaque(false);
        JLabel icon = new JLabel("🛵"); icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 26));
        JLabel name = new JLabel("NewWay");
        name.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 24));
        name.setForeground(new Color(200, 245, 240));
        topBar.add(icon); topBar.add(name);
        panel.add(topBar, BorderLayout.NORTH);

        // Bottom — ONLY the heading, nothing else
        JPanel bottom = new JPanel();
        bottom.setLayout(new BoxLayout(bottom, BoxLayout.Y_AXIS));
        bottom.setOpaque(false);
        bottom.setBorder(new EmptyBorder(0, 44, 68, 44));

        JLabel l1 = new JLabel("Intelligent");
        l1.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 48)); l1.setForeground(new Color(200, 160, 255));
        l1.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel l2 = new JLabel("Food Delivery");
        l2.setFont(F_HERO); l2.setForeground(WHITE);
        l2.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel l3 = new JLabel("Time Prediction");
        l3.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 40));
        l3.setForeground(new Color(255, 150, 60));
        l3.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel l4 = new JLabel("System");
        l4.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 40));
        l4.setForeground(new Color(220, 190, 255));
        l4.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Heading only — no badges
        bottom.add(l1); bottom.add(l2); bottom.add(l3); bottom.add(l4);
        panel.add(bottom, BorderLayout.SOUTH);
        return panel;
    }

    private JLabel badge(String text) {
        JLabel l = new JLabel(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255,255,255,18));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),20,20);
                g2.setColor(new Color(255,255,255,40)); g2.setStroke(new BasicStroke(0.8f));
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,20,20);
                g2.dispose(); super.paintComponent(g);
            }
        };
        l.setFont(new Font("Trebuchet MS",Font.BOLD,11));
        l.setForeground(new Color(200,245,240));
        l.setBorder(new EmptyBorder(5,12,5,12));
        l.setOpaque(false); return l;
    }

    // =====================================================================
    //  HERO PANEL — animated background
    // =====================================================================
    private class HeroPanel extends JPanel {
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            int W = getWidth(), H = getHeight();
            // Base
            GradientPaint bg = new GradientPaint(0,0,DEEP_BG,W,H,new Color(30,10,60));
            g2.setPaint(bg); g2.fillRect(0,0,W,H);
            // Animated orbs
            for (float[] o : orbDefs) {
                float t=(float)(animTick*o[7]*0.001f*1000);
                float ox=W*(o[0]+0.06f*(float)Math.sin(t+o[1]*10));
                float oy=H*(o[1]+0.06f*(float)Math.cos(t*0.7f+o[0]*8));
                float r=Math.min(W,H)*o[2];
                for(int pass=4;pass>=0;pass--){
                    float pr=r*(1f-pass*0.15f); int a=(int)((o[6]/255f)*255*(1.0-pass*0.18));
                    if(a<=0||pr<=0) continue;
                    Color c=new Color((int)o[3],(int)o[4],(int)o[5],Math.min(a,255));
                    RadialGradientPaint rg=new RadialGradientPaint(new Point2D.Float(ox,oy),pr,
                        new float[]{0f,1f},new Color[]{c,new Color((int)o[3],(int)o[4],(int)o[5],0)});
                    g2.setPaint(rg); g2.fillOval((int)(ox-pr),(int)(oy-pr),(int)(pr*2),(int)(pr*2));
                }
            }
            // Grain
            Random r2=new Random(42); g2.setColor(new Color(255,255,255,3));
            for(int y=0;y<H;y+=3) for(int x=0;x<W;x+=3) if(r2.nextInt(22)==0) g2.fillRect(x,y,1,1);
            // Arcs
            g2.setStroke(new BasicStroke(0.8f));
            for(int i=0;i<4;i++){g2.setColor(new Color(160,80,240,(int)(8+i*4)));int ar=W/2+i*45;g2.drawArc(W-ar/2,-ar/4,ar,ar,180,90);}
            for(int i=0;i<3;i++){g2.setColor(new Color(240,100,20,(int)(6+i*4)));int ar=(int)(H*0.8)+i*55;g2.drawArc(-ar/3,H-ar/2,ar,ar,0,70);}
            // Floats
            for(FoodFloat ff:floats) ff.paint(g2,W,H,animTick);
            // Sparks
            for(Spark s:sparks) s.paint(g2,W,H);
            // Bottom overlay
            GradientPaint ov=new GradientPaint(0,H*0.36f,new Color(0,0,0,0),0,H,new Color(18,8,40,235));
            g2.setPaint(ov); g2.fillRect(0,0,W,H);
            g2.dispose();
        }
    }

    // =====================================================================
    //  RIGHT FORM — Sign In / Create Account tabs
    // =====================================================================
    private JPanel buildFormPanel() {
        JPanel outer = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setColor(WHITE); g2.fillRect(0,0,getWidth(),getHeight()); g2.dispose();
            }
        };
        outer.setOpaque(false);

        JPanel container = new JPanel();
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
        container.setOpaque(false);
        container.setPreferredSize(new Dimension(400, 640));

        // Logo
        JPanel logoBadge = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        logoBadge.setOpaque(false); logoBadge.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel li=new JLabel("🛵"); li.setFont(new Font("Segoe UI Emoji",Font.PLAIN,22));
        JLabel ln=new JLabel("NewWay"); ln.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20)); ln.setForeground(TEAL);
        logoBadge.add(li); logoBadge.add(ln);

        // Tabs
        CardLayout cl = new CardLayout();
        JPanel body = new JPanel(cl);
        body.setOpaque(false); body.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel loginForm = buildLoginForm();
        JPanel regForm   = buildRegisterForm();

        // Wrap register form in scroll so the Create Account button is never clipped
        JScrollPane regScroll = new JScrollPane(regForm,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        regScroll.setOpaque(false);
        regScroll.getViewport().setOpaque(false);
        regScroll.setBorder(BorderFactory.createEmptyBorder());
        regScroll.getVerticalScrollBar().setUnitIncrement(16);

        body.add(loginForm, "LOGIN");
        body.add(regScroll,  "REGISTER");

        final boolean[] onLogin = {true};

        JPanel tabs = new JPanel(new GridLayout(1,2,0,0));
        tabs.setOpaque(false); tabs.setAlignmentX(Component.LEFT_ALIGNMENT);
        tabs.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));

        JButton tabLogin = tabBtn("🔑  Sign In",         onLogin, true);
        JButton tabReg   = tabBtn("✨  Create Account",  onLogin, false);
        tabLogin.addActionListener(e -> { onLogin[0]=true;  cl.show(body,"LOGIN");    tabs.repaint(); });
        tabReg.addActionListener(  e -> { onLogin[0]=false; cl.show(body,"REGISTER"); tabs.repaint(); });
        tabs.add(tabLogin); tabs.add(tabReg);

        container.add(logoBadge);
        container.add(Box.createVerticalStrut(18));
        container.add(tabs);
        container.add(Box.createVerticalStrut(2));
        container.add(body);
        outer.add(container);
        return outer;
    }

    private JButton tabBtn(String text, boolean[] flag, boolean iAmLogin) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                boolean active = (flag[0] == iAmLogin);
                g2.setColor(active ? WHITE : new Color(235,248,246));
                g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(active ? TEAL : BORDER_CLR);
                g2.fillRect(0,getHeight()-3,getWidth(),3);
                g2.setColor(active ? TEAL : WARM_GRAY);
                g2.setFont(active ? new Font("Trebuchet MS",Font.BOLD,13) : new Font("Trebuchet MS",Font.PLAIN,13));
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    // =====================================================================
    //  LOGIN FORM — no password text shown in hint cards
    // =====================================================================
    private JPanel buildLoginForm() {
        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setOpaque(false);
        form.setBorder(new EmptyBorder(22, 0, 16, 0));

        JLabel eyebrow = smallLabel("WELCOME BACK", TEAL);
        JLabel title   = new JLabel("Sign in to your account");
        title.setFont(F_TITLE); title.setForeground(CHARCOAL);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel sub = new JLabel("Track, order and predict — all in one place");
        sub.setFont(F_BODY); sub.setForeground(WARM_GRAY);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel div = gradientDivider(TEAL); div.setAlignmentX(Component.LEFT_ALIGNMENT);

        loginEmail = new JTextField(); styleInput(loginEmail);
        loginPass  = new JPasswordField(); styleInput(loginPass);

        JPanel fRow = new JPanel(new BorderLayout());
        fRow.setOpaque(false); fRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        fRow.setMaximumSize(new Dimension(9999,22));
        JLabel forgot = new JLabel("Forgot password?");
        forgot.setFont(F_SMALL); forgot.setForeground(TEAL);
        forgot.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        fRow.add(forgot, BorderLayout.EAST);

        loginMsg = new JLabel(" ");
        loginMsg.setFont(new Font("Trebuchet MS",Font.PLAIN,12));
        loginMsg.setForeground(new Color(190,60,40));
        loginMsg.setAlignmentX(Component.LEFT_ALIGNMENT);

        signInBtn = buildSignInButton();

        // Quick-fill cards — only show role + email, NO password text
        JPanel hintRow = new JPanel(new GridLayout(1,2,10,0));
        hintRow.setOpaque(false); hintRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        hintRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 62));
        hintRow.add(hintCard("👤  User",  "user@newway.com",  "user123"));
        hintRow.add(hintCard("🔧  Admin", "admin@newway.com", "admin123"));

        JLabel footer = new JLabel("");
        footer.setFont(new Font("Trebuchet MS",Font.PLAIN,10));
        footer.setForeground(new Color(160,180,178));
        footer.setAlignmentX(Component.CENTER_ALIGNMENT);

        form.add(eyebrow);    form.add(Box.createVerticalStrut(5));
        form.add(title);      form.add(Box.createVerticalStrut(4));
        form.add(sub);        form.add(Box.createVerticalStrut(18));
        form.add(div);        form.add(Box.createVerticalStrut(22));
        form.add(fieldLabel("[Mail]  EMAIL ADDRESS")); form.add(Box.createVerticalStrut(5));
        form.add(loginEmail); form.add(Box.createVerticalStrut(14));
        form.add(fieldLabel("[Lock]  PASSWORD"));     form.add(Box.createVerticalStrut(5));
        form.add(loginPass);  form.add(Box.createVerticalStrut(5));
        form.add(fRow);       form.add(Box.createVerticalStrut(3));
        form.add(loginMsg);   form.add(Box.createVerticalStrut(12));
        form.add(signInBtn);  form.add(Box.createVerticalStrut(18));
        form.add(hintRow);    form.add(Box.createVerticalStrut(16));
        form.add(footer);
        return form;
    }

    // =====================================================================
    //  REGISTER FORM
    // =====================================================================
    private JPanel buildRegisterForm() {
        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setOpaque(false);
        form.setBorder(new EmptyBorder(22, 0, 16, 0));

        JLabel eyebrow = smallLabel("JOIN NEWWAY", ORANGE);
        JLabel title = new JLabel("Create your account");
        title.setFont(F_TITLE); title.setForeground(CHARCOAL);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel sub = new JLabel("Start ordering in minutes");
        sub.setFont(F_BODY); sub.setForeground(WARM_GRAY);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel div = gradientDivider(ORANGE); div.setAlignmentX(Component.LEFT_ALIGNMENT);

        regName     = new JTextField(); styleInput(regName);
        regEmail    = new JTextField(); styleInput(regEmail);
        regPhone    = new JTextField(); styleInput(regPhone);
        regLocation = new JTextField("Hyderabad"); styleInput(regLocation);
        regPass     = new JPasswordField(); styleInput(regPass);
        regPass2    = new JPasswordField(); styleInput(regPass2);

        regMsg = new JLabel(" ");
        regMsg.setFont(new Font("Trebuchet MS",Font.PLAIN,12));
        regMsg.setForeground(new Color(190,60,40));
        regMsg.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton createBtn = buildCreateButton();

        form.add(eyebrow);      form.add(Box.createVerticalStrut(5));
        form.add(title);        form.add(Box.createVerticalStrut(4));
        form.add(sub);          form.add(Box.createVerticalStrut(16));
        form.add(div);          form.add(Box.createVerticalStrut(18));
        form.add(fieldLabel("[Name]  FULL NAME"));                                form.add(Box.createVerticalStrut(5));
        form.add(regName);      form.add(Box.createVerticalStrut(10));
        form.add(fieldLabel("[Mail]  EMAIL ADDRESS"));                             form.add(Box.createVerticalStrut(5));
        form.add(regEmail);     form.add(Box.createVerticalStrut(10));
        form.add(fieldLabel("[Ph]  PHONE NUMBER"));                                form.add(Box.createVerticalStrut(5));
        form.add(regPhone);     form.add(Box.createVerticalStrut(10));
        form.add(fieldLabel("[City]  CITY  ( Hyderabad / Nandyal / Kurnool )"));  form.add(Box.createVerticalStrut(5));
        form.add(regLocation);  form.add(Box.createVerticalStrut(10));
        form.add(fieldLabel("[Lock]  PASSWORD  (min 6 chars)"));                  form.add(Box.createVerticalStrut(5));
        form.add(regPass);      form.add(Box.createVerticalStrut(10));
        form.add(fieldLabel("[Lock]  CONFIRM PASSWORD"));                          form.add(Box.createVerticalStrut(5));
        form.add(regPass2);     form.add(Box.createVerticalStrut(5));
        form.add(regMsg);       form.add(Box.createVerticalStrut(14));
        form.add(createBtn);    form.add(Box.createVerticalStrut(16));
        return form;
    }

    // =====================================================================
    //  HINT CARD — role + email only, no password
    // =====================================================================
    private JPanel hintCard(String role, String email, String pass) {
        final boolean[] h={false};
        JPanel p=new JPanel(new BorderLayout(0,2)){
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                if(h[0]){GradientPaint gp=new GradientPaint(0,0,TEAL_LIGHT,0,getHeight(),new Color(200,240,238));g2.setPaint(gp);}
                else g2.setColor(new Color(246,252,251));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.setColor(h[0]?new Color(10,130,120,100):BORDER_CLR);
                g2.setStroke(new BasicStroke(1f)); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,10,10);
                if(h[0]){g2.setColor(TEAL);g2.fillRect(0,0,3,getHeight());}
                g2.dispose();
            }
        };
        p.setOpaque(false); p.setBorder(new EmptyBorder(8,12,8,12));
        p.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        JLabel rl=new JLabel(role); rl.setFont(new Font("Trebuchet MS",Font.BOLD,11)); rl.setForeground(TEAL);
        JLabel el=new JLabel(email); el.setFont(new Font("Trebuchet MS",Font.PLAIN,9)); el.setForeground(WARM_GRAY);
        // No password label — only "Click to auto-fill"
        JLabel cl2=new JLabel("🔑  Click to sign in"); cl2.setFont(new Font("Trebuchet MS",Font.ITALIC,9)); cl2.setForeground(new Color(150,180,178));
        JPanel info=new JPanel(); info.setLayout(new BoxLayout(info,BoxLayout.Y_AXIS)); info.setOpaque(false);
        info.add(rl); info.add(el); info.add(cl2);
        p.add(info, BorderLayout.CENTER);
        p.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){ loginEmail.setText(email); loginPass.setText(pass); }
            public void mouseEntered(MouseEvent e){ h[0]=true;  p.repaint(); }
            public void mouseExited (MouseEvent e){ h[0]=false; p.repaint(); }
        });
        return p;
    }

    // =====================================================================
    //  BUTTONS
    // =====================================================================
    private JButton buildSignInButton() {
        final boolean[] h={false};
        JButton b=new JButton("Sign In"){
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                if(h[0]){g2.setColor(new Color(108,45,180,45));g2.fillRoundRect(-4,-4,getWidth()+8,getHeight()+8,16,16);}
                GradientPaint gp=new GradientPaint(0,0,h[0]?TEAL_DK:TEAL,0,getHeight(),new Color(70,20,130));
                g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.setColor(new Color(255,255,255,28)); g2.fillRoundRect(2,2,getWidth()-4,getHeight()/2-2,8,8);
                g2.setColor(WHITE); g2.setFont(F_BTN);
                FontMetrics fm=g2.getFontMetrics(); String t=getText()+"  →";
                g2.drawString(t,(getWidth()-fm.stringWidth(t))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        b.addMouseListener(new MouseAdapter(){public void mouseEntered(MouseEvent e){h[0]=true;b.repaint();}public void mouseExited(MouseEvent e){h[0]=false;b.repaint();}});
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE,52)); b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e->doLogin());
        return b;
    }

    private JButton buildCreateButton() {
        final boolean[] h={false};
        JButton b=new JButton("Create Account"){
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp=new GradientPaint(0,0,h[0]?new Color(210,90,15):ORANGE,0,getHeight(),new Color(190,75,10));
                g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.setColor(new Color(255,255,255,28)); g2.fillRoundRect(2,2,getWidth()-4,getHeight()/2-2,8,8);
                g2.setColor(WHITE); g2.setFont(F_BTN);
                FontMetrics fm=g2.getFontMetrics(); String t="✨  "+getText()+"  →";
                g2.drawString(t,(getWidth()-fm.stringWidth(t))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        b.addMouseListener(new MouseAdapter(){public void mouseEntered(MouseEvent e){h[0]=true;b.repaint();}public void mouseExited(MouseEvent e){h[0]=false;b.repaint();}});
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE,52)); b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e->doRegister());
        return b;
    }

    private JLabel fieldLabel(String text) {
        // Convert [Tag] prefix to a colored symbol using HTML
        String display = text
            .replace("[Name]",  "<span style='color:#6C2DB4;font-weight:bold'>&#9786;</span>")
            .replace("[Mail]",  "<span style='color:#6C2DB4;font-weight:bold'>@</span>")
            .replace("[Ph]",    "<span style='color:#6C2DB4;font-weight:bold'>#</span>")
            .replace("[City]",  "<span style='color:#F06414;font-weight:bold'>&#9632;</span>")
            .replace("[Lock]",  "<span style='color:#6C2DB4;font-weight:bold'>*</span>");
        JLabel l = new JLabel("<html>" + display + "</html>");
        l.setFont(F_LABEL); l.setForeground(WARM_GRAY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT); return l;
    }
    private JLabel smallLabel(String text, Color c) {
        JLabel l=new JLabel(text); l.setFont(new Font("Trebuchet MS",Font.BOLD,10)); l.setForeground(c);
        l.setAlignmentX(Component.LEFT_ALIGNMENT); return l;
    }
    private void styleInput(JComponent c) {
        c.setBackground(INPUT_BG); c.setForeground(CHARCOAL);
        if(c instanceof javax.swing.text.JTextComponent tc) tc.setCaretColor(TEAL);
        c.setFont(F_INPUT);
        c.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER_CLR,1),new EmptyBorder(12,14,12,14)));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE,50)); c.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.addFocusListener(new FocusAdapter(){
            public void focusGained(FocusEvent e){c.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(TEAL,2),new EmptyBorder(11,13,11,13)));c.setBackground(WHITE);}
            public void focusLost(FocusEvent e){c.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER_CLR,1),new EmptyBorder(12,14,12,14)));c.setBackground(INPUT_BG);}
        });
    }
    private JPanel gradientDivider(Color c) {
        JPanel d=new JPanel(){@Override protected void paintComponent(Graphics g){
            Graphics2D g2=(Graphics2D)g.create();
            GradientPaint gp=new GradientPaint(0,0,c,(float)(getWidth()*0.45),0,BORDER_CLR);
            g2.setPaint(gp); g2.fillRect(0,1,getWidth(),2); g2.dispose();}};
        d.setOpaque(false); d.setMaximumSize(new Dimension(9999,4)); d.setPreferredSize(new Dimension(400,4));
        d.setAlignmentX(Component.LEFT_ALIGNMENT); return d;
    }
    private JPanel hairline() {
        JPanel l=new JPanel(){@Override protected void paintComponent(Graphics g){g.setColor(BORDER_CLR);g.fillRect(0,getHeight()/2,getWidth(),1);}};
        l.setOpaque(false); l.setPreferredSize(new Dimension(120,12)); return l;
    }

    // =====================================================================
    //  AUTH — LOGIN
    // =====================================================================
    private void doLogin() {
        String email=loginEmail.getText().trim();
        String pass=new String(loginPass.getPassword()).trim();
        if(email.isEmpty()||pass.isEmpty()){loginMsg.setText("⚠  Please enter email and password.");return;}
        signInBtn.setText("Signing in…"); signInBtn.setEnabled(false); loginMsg.setText(" ");
        new SwingWorker<User,Void>(){
            private String dbErr=null;
            @Override protected User doInBackground(){
                try{
                    java.sql.Connection conn=DBConnection.getInstance().getConnection();
                    try(PreparedStatement ps=conn.prepareStatement("SELECT * FROM users WHERE email=? AND password_hash=?")){
                        ps.setString(1,email); ps.setString(2,pass);
                        try(ResultSet rs=ps.executeQuery()){
                            if(rs.next()) return new User(rs.getInt("id"),rs.getString("full_name"),rs.getString("email"),rs.getString("role"),rs.getString("location"));
                        }
                    }
                }catch(DBConnection.DBException ex){dbErr=ex.getMessage();DBConnection.resetInstance();}
                catch(Exception ex){dbErr="Unexpected: "+ex.getMessage();}
                return null;
            }
            @Override protected void done(){
                signInBtn.setText("Sign In"); signInBtn.setEnabled(true);
                try{
                    User u=get();
                    if(dbErr!=null){loginMsg.setText("⚠  DB error — click for details.");showDBPopup(dbErr);}
                    else if(u!=null){clearFields();MainFrame.getInstance().onLoginSuccess(u);}
                    else loginMsg.setText("⚠  Invalid email or password.");
                }catch(Exception ex){loginMsg.setText("⚠  Unexpected error.");}
            }
        }.execute();
    }

    // =====================================================================
    //  AUTH — REGISTER
    // =====================================================================
    private void doRegister() {
        String name=regName.getText().trim(), email=regEmail.getText().trim();
        String phone=regPhone.getText().trim(), loc=regLocation.getText().trim();
        String pass=new String(regPass.getPassword()).trim();
        String pass2=new String(regPass2.getPassword()).trim();
        if(name.isEmpty()||email.isEmpty()||pass.isEmpty()){regMsg.setForeground(new Color(190,60,40));regMsg.setText("⚠  Name, email and password are required.");return;}
        if(!pass.equals(pass2)){regMsg.setForeground(new Color(190,60,40));regMsg.setText("⚠  Passwords do not match.");return;}
        if(pass.length()<6){regMsg.setForeground(new Color(190,60,40));regMsg.setText("⚠  Password must be at least 6 characters.");return;}
        regMsg.setForeground(WARM_GRAY); regMsg.setText("⏳  Creating account…");
        new SwingWorker<Boolean,Void>(){
            private String err=null;
            @Override protected Boolean doInBackground(){
                try{
                    java.sql.Connection conn=DBConnection.getInstance().getConnection();
                    try(PreparedStatement ps=conn.prepareStatement("SELECT id FROM users WHERE email=?")){
                        ps.setString(1,email);
                        try(ResultSet rs=ps.executeQuery()){if(rs.next()){err="⚠  Email already registered.";return false;}}
                    }
                    try(PreparedStatement ps=conn.prepareStatement("INSERT INTO users(full_name,email,password_hash,phone,location,role) VALUES(?,?,?,?,?,'user')")){
                        ps.setString(1,name); ps.setString(2,email); ps.setString(3,pass);
                        ps.setString(4,phone.isEmpty()?"":phone); ps.setString(5,loc.isEmpty()?"Hyderabad":loc);
                        ps.executeUpdate();
                    }
                    return true;
                }catch(DBConnection.DBException ex){err=ex.getMessage();DBConnection.resetInstance();return false;}
                catch(Exception ex){err="DB error: "+ex.getMessage();return false;}
            }
            @Override protected void done(){
                try{
                    if(get()){regMsg.setForeground(new Color(20,130,100));regMsg.setText("✅  Account created! You can now sign in.");}
                    else{regMsg.setForeground(new Color(190,60,40));regMsg.setText(err!=null?err:"⚠  Could not create account.");}
                }catch(Exception ex){regMsg.setText("⚠  Unexpected error.");}
            }
        }.execute();
    }

    private void showDBPopup(String message) {
        JPanel c=new JPanel(new BorderLayout(0,14)); c.setBorder(new EmptyBorder(8,8,4,8)); c.setBackground(WHITE);
        JLabel icon=new JLabel("🔌  Database Connection Failed"); icon.setFont(new Font("Georgia",Font.BOLD,16)); icon.setForeground(TEAL);
        JTextArea area=new JTextArea(message); area.setFont(new Font("Trebuchet MS",Font.PLAIN,13));
        area.setBackground(new Color(245,252,251)); area.setBorder(new EmptyBorder(12,14,12,14));
        area.setEditable(false); area.setLineWrap(true); area.setWrapStyleWord(true); area.setPreferredSize(new Dimension(440,110));
        c.add(icon,BorderLayout.NORTH); c.add(area,BorderLayout.CENTER);
        JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),c,"NewWay — DB Error",JOptionPane.ERROR_MESSAGE);
    }

    private void clearFields(){loginEmail.setText("");loginPass.setText("");loginMsg.setText(" ");}
    public void stopAnimation(){if(animTimer!=null)animTimer.stop();}

    // =====================================================================
    //  INNER CLASSES
    // =====================================================================
    private static class FoodFloat {
        final String emoji; final float bx,by; final int pr; final Color pc; final float phase;
        FoodFloat(String e,float x,float y,int r,Color c,float p){emoji=e;bx=x;by=y;pr=r;pc=c;phase=p;}
        void paint(Graphics2D g2,int W,int H,double t){
            float oy=(float)(Math.sin(t*0.85+phase)*9);
            float ss=(float)(1.0+Math.sin(t*0.85+phase+Math.PI)*0.15);
            float cx=W*bx, cy=H*by+oy, gy=H*by+pr*0.55f;
            int sw=(int)(pr*1.6*ss), sh=(int)(pr*0.38*ss);
            g2.setColor(new Color(0,0,0,40)); g2.fillOval((int)(cx-sw/2),(int)(gy-sh/2),sw,sh);
            g2.setColor(new Color(220,240,238,150)); g2.fillOval((int)(cx-pr),(int)(cy-pr),pr*2,pr*2);
            RadialGradientPaint rg=new RadialGradientPaint(new Point2D.Float(cx-pr*0.2f,cy-pr*0.25f),pr*0.9f,
                new float[]{0f,0.7f,1f},new Color[]{pc.brighter(),pc,pc.darker()});
            g2.setPaint(rg); g2.fillOval((int)(cx-pr*0.86f),(int)(cy-pr*0.86f),(int)(pr*1.72f),(int)(pr*1.72f));
            g2.setColor(new Color(255,255,255,40)); g2.fillOval((int)(cx-pr*0.44f),(int)(cy-pr*0.54f),(int)(pr*0.48f),(int)(pr*0.26f));
            g2.setFont(new Font("Segoe UI Emoji",Font.PLAIN,(int)(pr*0.68)));
            FontMetrics fm=g2.getFontMetrics();
            g2.drawString(emoji,cx-fm.stringWidth(emoji)/2f,cy+fm.getAscent()*0.34f);
        }
    }
    private class Spark {
        float x,y,vx,vy,life,max,sz; Color col;
        Spark(){reset(); life=rng.nextFloat()*100;}
        void reset(){x=rng.nextFloat();y=rng.nextFloat()*1.1f;vx=(rng.nextFloat()-0.5f)*0.0003f;vy=-rng.nextFloat()*0.0005f-0.0002f;max=80+rng.nextInt(120);life=0;sz=1f+rng.nextFloat()*2.5f;int t=rng.nextInt(3);col=t==0?new Color(180,100,255,200):t==1?new Color(255,120,40,180):new Color(220,160,255,160);}
        void update(){x+=vx;y+=vy;life++;if(life>max||x<0||x>1||y<-0.1)reset();}
        void paint(Graphics2D g2,int W,int H){float a=(float)Math.sin(Math.PI*life/max);int alpha=(int)(a*col.getAlpha());if(alpha<=0)return;g2.setColor(new Color(col.getRed(),col.getGreen(),col.getBlue(),alpha));int px=(int)(x*W),py=(int)(y*H),s=(int)sz;g2.fillOval(px-s/2,py-s/2,s,s);if(sz>2){g2.setStroke(new BasicStroke(0.7f));g2.setColor(new Color(col.getRed(),col.getGreen(),col.getBlue(),alpha/2));g2.drawLine(px-s,py,px+s,py);g2.drawLine(px,py-s,px,py+s);}}
    }
}
