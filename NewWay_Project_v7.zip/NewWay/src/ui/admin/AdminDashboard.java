package ui.admin;

import db.DBConnection;
import db.OrderDAO;
import db.OrderDAO.RiderConflictException;
import db.OrderDAO.CancelException;
import model.Order;
import model.Rider;
import ui.MainFrame;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.sql.*;
import java.util.*;
import java.util.List;

public class AdminDashboard extends JPanel {

    // ── Palette ───────────────────────────────────────────────────────────────
    private static final Color WHITE      = Color.WHITE;
    private static final Color BG         = new Color(250, 248, 255);
    private static final Color TEAL       = new Color(108,  45, 180);  // Purple
    private static final Color TEAL_DK    = new Color( 80,  28, 140);
    private static final Color TEAL_LIGHT = new Color(245, 238, 255);
    private static final Color ORANGE     = new Color(240, 100,  20);
    private static final Color ROSE       = TEAL;
    private static final Color ROSE_DK    = TEAL_DK;
    private static final Color CHARCOAL   = new Color(20,  18,  30);
    private static final Color WARM_GRAY  = new Color(110, 100, 125);
    private static final Color BORDER     = new Color(220, 210, 235);
    private static final Color GREEN      = new Color(32,  130,  72);
    private static final Color AMBER      = new Color(200, 120,  20);
    private static final Color BLUE_STAT  = new Color( 30,  90, 200);
    private static final Color ROSE_LIGHT = new Color(245, 238, 255);
    private static final Color PURPLE     = new Color(108,  45, 180);

    // ── Fonts (premium style) ─────────────────────────────────────────────────
    private static final Font F_DISPLAY  = new Font("Georgia",      Font.BOLD | Font.ITALIC, 22);
    private static final Font F_HEADING  = new Font("Georgia",      Font.BOLD,               16);
    private static final Font F_BODY     = new Font("Trebuchet MS", Font.PLAIN,               13);
    private static final Font F_LABEL    = new Font("Trebuchet MS", Font.BOLD,                10);
    private static final Font F_SMALL    = new Font("Trebuchet MS", Font.PLAIN,               11);
    private static final Font F_BTN      = new Font("Trebuchet MS", Font.BOLD,                12);
    private static final Font F_TABLE    = new Font("Trebuchet MS", Font.PLAIN,               13);
    private static final Font F_TABLE_HD = new Font("Trebuchet MS", Font.BOLD,                10);
    private static final Font F_NUM_BIG  = new Font("Georgia",      Font.BOLD,                36);
    private static final Font F_NUM_MED  = new Font("Georgia",      Font.BOLD,                22);

    // ── Tables ────────────────────────────────────────────────────────────────
    private JTable ordersTable;
    private DefaultTableModel ordersModel;
    private JTable ridersTable;
    private DefaultTableModel ridersModel;

    // ── Stat labels ───────────────────────────────────────────────────────────
    private JLabel statTodayOrders, statTodayRevenue, statPending, statActive, statRiders, statDone;

    public AdminDashboard() {
        setLayout(new BorderLayout());
        setBackground(BG);
        buildUI();
    }

    private void buildUI() {
        add(buildNavBar(),  BorderLayout.NORTH);
        add(buildContent(), BorderLayout.CENTER);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  TOP NAVIGATION
    // ═══════════════════════════════════════════════════════════════════════
    private JPanel buildNavBar() {
        JPanel nav = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(WHITE); g.fillRect(0,0,getWidth(),getHeight());
                g.setColor(BORDER); g.drawLine(0,getHeight()-1,getWidth(),getHeight()-1);
            }
        };
        nav.setOpaque(false);
        nav.setPreferredSize(new Dimension(0, 66));
        nav.setBorder(new EmptyBorder(0, 28, 0, 28));

        // ── Left: Logo ────────────────────────────────────────────────────
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        JLabel logoIcon = new JLabel("🛵");
        logoIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));
        JLabel logoName = new JLabel("NewWay");
        logoName.setFont(F_DISPLAY);
        logoName.setForeground(CHARCOAL);
        JLabel adminBadge = new JLabel("  ADMIN  ");
        adminBadge.setFont(F_LABEL);
        adminBadge.setForeground(WHITE);
        adminBadge.setBackground(ROSE);
        adminBadge.setOpaque(true);
        adminBadge.setBorder(new EmptyBorder(3, 8, 3, 8));
        left.add(logoIcon); left.add(logoName); left.add(adminBadge);

        // ── Center: Title ─────────────────────────────────────────────────
        JLabel centerTitle = new JLabel("Delivery Management Console", SwingConstants.CENTER);
        centerTitle.setFont(new Font("Georgia", Font.ITALIC, 15));
        centerTitle.setForeground(WARM_GRAY);

        // ── Right: Actions ────────────────────────────────────────────────
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);

        JButton autoBtn     = navBtn("⚡  Auto-Assign", ROSE);
        JButton refreshBtn  = navBtn("⟳  Refresh",     new Color(50,50,50));
        JButton logoutBtn   = navBtn("Sign Out",        WARM_GRAY);

        autoBtn.addActionListener(e -> autoAssignAll());
        refreshBtn.addActionListener(e -> refresh());
        logoutBtn.addActionListener(e -> MainFrame.getInstance().logout());

        right.add(autoBtn); right.add(refreshBtn); right.add(logoutBtn);

        nav.add(left,        BorderLayout.WEST);
        nav.add(centerTitle, BorderLayout.CENTER);
        nav.add(right,       BorderLayout.EAST);
        return nav;
    }

    private JButton navBtn(String text, Color bg) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? bg.darker() : bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),20,20);
                g2.setColor(WHITE); g2.setFont(F_BTN);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,
                    (getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(text.length()*8+20, 36));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  MAIN CONTENT
    // ═══════════════════════════════════════════════════════════════════════
    private JPanel buildContent() {
        JPanel c = new JPanel(new BorderLayout());
        c.setBackground(BG);

        // Stats section
        JPanel statsSection = new JPanel(new BorderLayout());
        statsSection.setBackground(BG);
        statsSection.setBorder(new EmptyBorder(18, 24, 0, 24));

        // Row 1: Today's summary (larger)
        JPanel todayRow = new JPanel(new GridLayout(1, 2, 14, 0));
        todayRow.setBackground(BG);
        todayRow.setPreferredSize(new Dimension(0, 110));

        statTodayOrders  = new JLabel("0");
        statTodayRevenue = new JLabel("₹0");

        todayRow.add(todayCard("TODAY'S ORDERS",  statTodayOrders,  ROSE,      "Total orders placed today",       "📋"));
        todayRow.add(todayCard("TODAY'S REVENUE",  statTodayRevenue, GREEN,     "Total revenue collected today",   "💰"));

        // Row 2: Live stats
        JPanel liveRow = new JPanel(new GridLayout(1, 4, 14, 0));
        liveRow.setBackground(BG);
        liveRow.setBorder(new EmptyBorder(14, 0, 0, 0));
        liveRow.setPreferredSize(new Dimension(0, 90));

        statPending = new JLabel("0");
        statActive  = new JLabel("0");
        statRiders  = new JLabel("0");
        statDone    = new JLabel("0");

        liveRow.add(miniStatCard("⏳  Pending",    statPending, AMBER));
        liveRow.add(miniStatCard("🚀  Active",     statActive,  ROSE));
        liveRow.add(miniStatCard("🏍  Available Riders", statRiders,  GREEN));
        liveRow.add(miniStatCard("✅  Delivered",  statDone,    BLUE_STAT));

        statsSection.add(todayRow, BorderLayout.NORTH);
        statsSection.add(liveRow,  BorderLayout.CENTER);

        // Tabs
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(BG);
        tabs.setFont(F_BODY);
        tabs.setBorder(new EmptyBorder(0,16,0,16));
        tabs.addTab("📋   Active Orders",    buildOrdersTab());
        tabs.addTab("🏍   Rider Management", buildRidersTab());

        c.add(statsSection, BorderLayout.NORTH);
        c.add(tabs,          BorderLayout.CENTER);
        return c;
    }

    // ── Today large cards ─────────────────────────────────────────────────────
    private JPanel todayCard(String title, JLabel valueLbl, Color accent, String sub, String icon) {
        JPanel card = new JPanel(new BorderLayout(0, 6)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Card
                g2.setColor(new Color(0,0,0,10));
                g2.fillRoundRect(3,3,getWidth()-2,getHeight()-2,14,14);
                g2.setColor(WHITE);
                g2.fillRoundRect(0,0,getWidth()-4,getHeight()-4,14,14);
                // Bottom accent bar
                GradientPaint gp = new GradientPaint(0,getHeight()-7,accent,getWidth()*0.6f,getHeight()-7,new Color(accent.getRed(),accent.getGreen(),accent.getBlue(),0));
                g2.setPaint(gp);
                g2.fillRoundRect(0,getHeight()-8,getWidth()-4,8,6,6);
                // Big icon ghost
                g2.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 52));
                g2.setColor(new Color(accent.getRed(),accent.getGreen(),accent.getBlue(),18));
                g2.drawString(icon, getWidth()-100, getHeight()-8);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(16, 24, 16, 24));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(F_LABEL);
        titleLbl.setForeground(WARM_GRAY);

        valueLbl.setFont(F_NUM_BIG);
        valueLbl.setForeground(accent);

        JLabel subLbl = new JLabel(sub);
        subLbl.setFont(F_SMALL);
        subLbl.setForeground(new Color(175,168,155));

        JPanel mid = new JPanel(new BorderLayout());
        mid.setOpaque(false);
        mid.add(valueLbl, BorderLayout.CENTER);
        mid.add(subLbl,   BorderLayout.SOUTH);

        card.add(titleLbl, BorderLayout.NORTH);
        card.add(mid,      BorderLayout.CENTER);
        return card;
    }

    // ── Mini stat cards ───────────────────────────────────────────────────────
    private JPanel miniStatCard(String label, JLabel valueLbl, Color accent) {
        JPanel card = new JPanel(new BorderLayout(0, 4)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,8));
                g2.fillRoundRect(3,3,getWidth()-2,getHeight()-2,12,12);
                g2.setColor(WHITE);
                g2.fillRoundRect(0,0,getWidth()-4,getHeight()-4,12,12);
                // Left bar
                g2.setColor(accent);
                g2.fillRoundRect(0,0,5,getHeight()-4,4,4);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(12, 20, 12, 12));

        JLabel lbl = new JLabel(label);
        lbl.setFont(F_LABEL);
        lbl.setForeground(WARM_GRAY);

        valueLbl.setFont(F_NUM_MED);
        valueLbl.setForeground(accent);

        card.add(lbl,      BorderLayout.NORTH);
        card.add(valueLbl, BorderLayout.CENTER);
        return card;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  ORDERS TAB — Assign Rider  +  Delete (soft) columns
    // ═══════════════════════════════════════════════════════════════════════
    private JPanel buildOrdersTab() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(BG);
        p.setBorder(new EmptyBorder(16, 8, 16, 8));

        // 9 columns: last two are action buttons
        String[] cols = {"Order ID","Customer","Status","Rider","ETA","Amount (₹)","Placed At","Assign","Delete"};
        ordersModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return c == 7 || c == 8; }
        };
        ordersTable = new JTable(ordersModel);
        styleTable(ordersTable);

        // Assign Rider column (7)
        ordersTable.getColumnModel().getColumn(7).setCellRenderer(new RoseBtnRenderer("Assign Rider"));
        ordersTable.getColumnModel().getColumn(7).setCellEditor(
            new RoseBtnEditor(new JCheckBox(), TEAL, "Assign Rider", this::openAssignDialog));
        ordersTable.getColumnModel().getColumn(7).setPreferredWidth(110);

        // Delete column (8) — red
        ordersTable.getColumnModel().getColumn(8).setCellRenderer(new RedBtnRenderer("Cancel Order"));
        ordersTable.getColumnModel().getColumn(8).setCellEditor(
            new RoseBtnEditor(new JCheckBox(), new Color(195, 40, 40), "Cancel Order", this::doDeleteOrder));
        ordersTable.getColumnModel().getColumn(8).setPreferredWidth(100);

        ordersTable.getColumnModel().getColumn(2).setCellRenderer(new StatusCellRenderer());
        ordersTable.getColumnModel().getColumn(0).setPreferredWidth(70);
        ordersTable.getColumnModel().getColumn(4).setPreferredWidth(70);

        JScrollPane sc = new JScrollPane(ordersTable);
        sc.setBorder(BorderFactory.createLineBorder(BORDER, 1));
        sc.getViewport().setBackground(WHITE);
        p.add(sc, BorderLayout.CENTER);
        return p;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  RIDERS TAB — full CRUD (Add / Edit / Delete)
    // ═══════════════════════════════════════════════════════════════════════
    private JPanel buildRidersTab() {
        JPanel p = new JPanel(new BorderLayout(0, 0));
        p.setBackground(BG);
        p.setBorder(new EmptyBorder(16, 8, 16, 8));

        // Table — 8 cols, last two are Edit / Delete action buttons
        String[] cols = {"ID","Rider Name","Phone Number","Vehicle","Status","Deliveries","Rating","Edit","Delete"};
        ridersModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return c == 7 || c == 8; }
        };
        ridersTable = new JTable(ridersModel);
        styleTable(ridersTable);
        ridersTable.getColumnModel().getColumn(4).setCellRenderer(new RiderStatusRenderer());
        ridersTable.getColumnModel().getColumn(0).setPreferredWidth(40);
        ridersTable.getColumnModel().getColumn(2).setPreferredWidth(125);

        // Edit (7) — teal
        ridersTable.getColumnModel().getColumn(7).setCellRenderer(new RoseBtnRenderer("Edit Rider"));
        ridersTable.getColumnModel().getColumn(7).setCellEditor(
            new RoseBtnEditor(new JCheckBox(), TEAL, "Edit Rider", this::doEditRider));
        ridersTable.getColumnModel().getColumn(7).setPreferredWidth(90);

        // Delete (8) — red
        ridersTable.getColumnModel().getColumn(8).setCellRenderer(new RedBtnRenderer("Delete"));
        ridersTable.getColumnModel().getColumn(8).setCellEditor(
            new RoseBtnEditor(new JCheckBox(), new Color(195, 40, 40), "Delete", this::doDeleteRider));
        ridersTable.getColumnModel().getColumn(8).setPreferredWidth(80);

        JScrollPane sc = new JScrollPane(ridersTable);
        sc.setBorder(BorderFactory.createLineBorder(BORDER, 1));
        sc.getViewport().setBackground(WHITE);

        // ── Toolbar: Add Rider button ────────────────────────────────────────
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        toolbar.setBackground(BG);
        JButton addBtn = navBtn("+ Add New Rider", GREEN);
        addBtn.addActionListener(e -> doAddRider());
        toolbar.add(addBtn);

        p.add(toolbar, BorderLayout.NORTH);
        p.add(sc,      BorderLayout.CENTER);
        return p;
    }

    // ── Table styling ─────────────────────────────────────────────────────────
    private void styleTable(JTable t) {
        t.setBackground(WHITE);
        t.setForeground(CHARCOAL);
        t.setGridColor(new Color(238, 232, 222));
        t.setRowHeight(44);
        t.setFont(F_TABLE);
        t.setSelectionBackground(ROSE_LIGHT);
        t.setSelectionForeground(CHARCOAL);
        t.setShowGrid(true);
        t.setFillsViewportHeight(true);
        t.setIntercellSpacing(new Dimension(1, 1));

        JTableHeader h = t.getTableHeader();
        h.setBackground(new Color(252, 248, 242));
        h.setForeground(WARM_GRAY);
        h.setFont(F_TABLE_HD);
        h.setPreferredSize(new Dimension(0, 38));
        h.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, BORDER));
        h.setReorderingAllowed(false);

        // Striped row renderer
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable tbl, Object v, boolean sel, boolean f, int r, int c) {
                Component comp = super.getTableCellRendererComponent(tbl, v, sel, f, r, c);
                if (!sel) comp.setBackground(r % 2 == 0 ? WHITE : new Color(252, 250, 246));
                comp.setForeground(CHARCOAL);
                comp.setFont(F_TABLE);
                ((JLabel) comp).setBorder(new EmptyBorder(0, 14, 0, 14));
                return comp;
            }
        });
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  LOAD DATA
    // ═══════════════════════════════════════════════════════════════════════
    private void loadOrders() {
        new SwingWorker<List<Order>, Void>() {
            @Override protected List<Order> doInBackground() throws Exception {
                return new OrderDAO().getAllOrders(); // includes Delivered + Cancelled
            }
            @Override protected void done() {
                try {
                    ordersModel.setRowCount(0);
                    long pending = 0, active = 0, done = 0;
                    double todayRevenue = 0; int todayCount = 0;
                    java.time.LocalDate today = java.time.LocalDate.now();
                    for (Order o : get()) {
                        if (o.getStatus() == Order.Status.Pending)  pending++;
                        if (o.getStatus() == Order.Status.Assigned
                         || o.getStatus() == Order.Status.OutForDelivery) active++;
                        if (o.getStatus() == Order.Status.Delivered) done++;
                        if (o.getPlacedAt() != null && o.getPlacedAt().toLocalDate().equals(today)) {
                            todayCount++;
                            if (o.getTotalPrice() != null)
                                todayRevenue += o.getTotalPrice().doubleValue();
                        }
                        // 9 cols — col7=Assign, col8=Delete
                        ordersModel.addRow(new Object[]{
                            "#" + o.getId(),
                            o.getUserName() != null ? o.getUserName() : "—",
                            o.getStatus().name(),
                            o.getRiderName() != null ? o.getRiderName() : "—",
                            o.getPredictedTimeMin() != null ? o.getPredictedTimeMin() + " min" : "?",
                            "\u20b9" + (o.getTotalPrice() != null ? o.getTotalPrice().toPlainString() : "0"),
                            o.getPlacedAt() != null ? o.getPlacedAt().toString().substring(0,16) : "—",
                            "Assign Rider",
                            "\ud83d\uddd1 Cancel"
                        });
                    }
                    statPending.setText(String.valueOf(pending));
                    statActive.setText(String.valueOf(active));
                    statDone.setText(String.valueOf(done));
                    statTodayOrders.setText(String.valueOf(todayCount));
                    statTodayRevenue.setText("\u20b9" + String.format("%,.0f", todayRevenue));
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        }.execute();
    }

    private void loadRiders() {
        new SwingWorker<List<Rider>, Void>() {
            @Override protected List<Rider> doInBackground() throws Exception { return fetchAllRiders(); }
            @Override protected void done() {
                try {
                    ridersModel.setRowCount(0); long avail = 0;
                    for (Rider r : get()) {
                        if (r.getStatus() == Rider.Status.Available) avail++;
                        ridersModel.addRow(new Object[]{
                            r.getId(), r.getFullName(), r.getPhone(),
                            r.getVehicleType(),
                            r.getStatus().name().replace("OnDelivery","On Delivery"),
                            r.getTotalDeliveries(),
                            String.format("%.1f \u2605", r.getRating()),
                            "\u270f Edit",
                            "\ud83d\uddd1 Delete"
                        });
                    }
                    statRiders.setText(String.valueOf(avail));
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        }.execute();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  RIDER ASSIGNMENT
    // ═══════════════════════════════════════════════════════════════════════
    private void openAssignDialog(int row) {
        String cell   = (String) ordersModel.getValueAt(row, 0);
        String status = (String) ordersModel.getValueAt(row, 2);
        int orderId   = Integer.parseInt(cell.replace("#", "").trim());

        if (!"Pending".equals(status)) {
            JOptionPane.showMessageDialog(this,
                "Only Pending orders can be assigned.\nThis order is: " + status,
                "Cannot Assign", JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<Rider> avail = fetchAvailableRiders();
        if (avail.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "No available riders at the moment.", "No Riders", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String[] opts = avail.stream()
            .map(r -> "#" + r.getId() + "  " + r.getFullName()
                    + "  |  📞 " + r.getPhone()
                    + "  |  ★ " + String.format("%.1f", r.getRating()))
            .toArray(String[]::new);

        String choice = (String) JOptionPane.showInputDialog(this,
            "<html><b>Assign Rider to Order " + cell + "</b><br>"
            + "Select an available rider:</html>",
            "Rider Assignment", JOptionPane.PLAIN_MESSAGE, null, opts, opts[0]);

        if (choice == null) return;
        int riderId = avail.get(List.of(opts).indexOf(choice)).getId();

        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() throws Exception {
                new OrderDAO().assignRider(orderId, riderId); return null;
            }
            @Override protected void done() {
                try {
                    get();
                    JOptionPane.showMessageDialog(AdminDashboard.this,
                        "✅  Rider assigned successfully!", "Done", JOptionPane.INFORMATION_MESSAGE);
                    refresh();
                } catch (Exception ex) {
                    Throwable c = ex.getCause();
                    JOptionPane.showMessageDialog(AdminDashboard.this,
                        "⚠  " + (c != null ? c.getMessage() : ex.getMessage()),
                        c instanceof RiderConflictException ? "Conflict" : "Error",
                        JOptionPane.WARNING_MESSAGE);
                }
            }
        }.execute();
    }

    private void openCancelDialog(int row) {
        String cell   = (String) ordersModel.getValueAt(row, 0);
        String status = (String) ordersModel.getValueAt(row, 2);
        int orderId   = Integer.parseInt(cell.replace("#", "").trim());

        if ("Cancelled".equals(status) || "Delivered".equals(status)) {
            JOptionPane.showMessageDialog(this,
                "This order cannot be cancelled (status: " + status + ").",
                "Cannot Cancel", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "<html><b>❌ Cancel Order #" + orderId + "?</b><br><br>"
          + "Status: <b>" + status + "</b><br>"
          + "<small>The order will be marked Cancelled and preserved for history.</small></html>",
            "Confirm Cancellation", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        new SwingWorker<Void,Void>() {
            @Override protected Void doInBackground() throws Exception {
                new OrderDAO().cancelOrder(orderId); return null;
            }
            @Override protected void done() {
                try {
                    get();
                    JOptionPane.showMessageDialog(AdminDashboard.this,
                        "✅  Order #" + orderId + " cancelled successfully.","Done", JOptionPane.INFORMATION_MESSAGE);
                    refresh();
                } catch (Exception ex) {
                    Throwable c = ex.getCause();
                    JOptionPane.showMessageDialog(AdminDashboard.this,
                        "⚠  " + (c != null ? c.getMessage() : ex.getMessage()),
                        c instanceof CancelException ? "Cannot Cancel" : "Error",
                        JOptionPane.WARNING_MESSAGE);
                }
            }
        }.execute();
    }


    private void autoAssignAll() {
        int assigned = 0, failed = 0;
        try {
            List<Order> pending = new OrderDAO().getActiveOrders().stream()
                .filter(o -> o.getStatus() == Order.Status.Pending).toList();
            List<Rider> avail = fetchAvailableRiders();
            for (Order o : pending) {
                if (avail.isEmpty()) break;
                Rider r = avail.remove(0);
                try { new OrderDAO().assignRider(o.getId(), r.getId()); assigned++; }
                catch (RiderConflictException e) { failed++; }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(this,
            "Auto-assign complete.\n✅  " + assigned + " assigned   ⚠  " + failed + " skipped.",
            "Auto-Assign Result", JOptionPane.INFORMATION_MESSAGE);
        refresh();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  SOFT DELETE ORDER (Admin — can cancel Pending or Assigned orders)
    // ═══════════════════════════════════════════════════════════════════════
    private void doDeleteOrder(int row) {
        String cell   = (String) ordersModel.getValueAt(row, 0);
        String status = (String) ordersModel.getValueAt(row, 2);
        int orderId   = Integer.parseInt(cell.replace("#", "").trim());

        if ("Delivered".equals(status) || "Cancelled".equals(status)) {
            JOptionPane.showMessageDialog(this,
                "Order #" + orderId + " is already " + status + " — cannot cancel.",
                "Cannot Cancel", JOptionPane.WARNING_MESSAGE); return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
            "<html><b>Cancel Order #" + orderId + "?</b><br>"
            + "Customer: " + ordersModel.getValueAt(row, 1) + "<br>"
            + "Amount: "   + ordersModel.getValueAt(row, 5) + "<br><br>"
            + "This will soft-delete the order (status → Cancelled).<br>"
            + "The record is kept for audit purposes.</html>",
            "Confirm Cancellation", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        new SwingWorker<Void, Void>() {
            String errMsg = null;
            @Override protected Void doInBackground() {
                try { new OrderDAO().softDeleteOrder(orderId, true); }
                catch (Exception ex) { errMsg = ex.getMessage(); }
                return null;
            }
            @Override protected void done() {
                if (errMsg != null) {
                    JOptionPane.showMessageDialog(AdminDashboard.this,
                        "⚠  " + errMsg, "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(AdminDashboard.this,
                        "✅  Order #" + orderId + " cancelled successfully.",
                        "Order Cancelled", JOptionPane.INFORMATION_MESSAGE);
                    refresh();
                }
            }
        }.execute();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  RIDER CRUD ACTIONS
    // ═══════════════════════════════════════════════════════════════════════
    private void doAddRider() {
        JPanel form = riderForm(null, "", "", "Motorcycle");
        String[] opts = {"➕  Add Rider", "✕  Cancel"};
        int res = JOptionPane.showOptionDialog(this, form, "NewWay — Add New Rider",
            JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, opts, opts[0]);
        if (res != 0) return;
        String name    = ((JTextField) form.getClientProperty("name")).getText().trim();
        String phone   = ((JTextField) form.getClientProperty("phone")).getText().trim();
        String vehicle = (String) ((JComboBox<?>) form.getClientProperty("vehicle")).getSelectedItem();
        if (name.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠  Name and phone are required."); return;
        }
        new SwingWorker<Integer, Void>() {
            String err = null;
            @Override protected Integer doInBackground() {
                try { return new OrderDAO().addRider(name, phone, vehicle); }
                catch (Exception ex) { err = ex.getMessage(); return -1; }
            }
            @Override protected void done() {
                try {
                    int id = get();
                    if (id > 0) {
                        JOptionPane.showMessageDialog(AdminDashboard.this,
                            "✅  Rider added! ID: " + id, "Success", JOptionPane.INFORMATION_MESSAGE);
                        refresh();
                    } else {
                        JOptionPane.showMessageDialog(AdminDashboard.this,
                            "❌  " + err, "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        }.execute();
    }

    private void doEditRider(int row) {
        int    id      = (int)    ridersModel.getValueAt(row, 0);
        String name    = (String) ridersModel.getValueAt(row, 1);
        String phone   = (String) ridersModel.getValueAt(row, 2);
        String vehicle = (String) ridersModel.getValueAt(row, 3);
        String status  = (String) ridersModel.getValueAt(row, 4);

        JPanel form = riderForm(status, name, phone, vehicle);
        String[] opts = {"💾  Save Changes", "✕  Cancel"};
        int res = JOptionPane.showOptionDialog(this, form, "NewWay — Edit Rider #" + id,
            JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, opts, opts[0]);
        if (res != 0) return;

        String newName    = ((JTextField) form.getClientProperty("name")).getText().trim();
        String newPhone   = ((JTextField) form.getClientProperty("phone")).getText().trim();
        String newVehicle = (String) ((JComboBox<?>) form.getClientProperty("vehicle")).getSelectedItem();
        String newStatus  = (String) ((JComboBox<?>) form.getClientProperty("status")).getSelectedItem();
        if (newName.isEmpty() || newPhone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠  Name and phone are required."); return;
        }
        new SwingWorker<Void, Void>() {
            String err = null;
            @Override protected Void doInBackground() {
                try { new OrderDAO().updateRider(id, newName, newPhone, newVehicle, newStatus); }
                catch (Exception ex) { err = ex.getMessage(); }
                return null;
            }
            @Override protected void done() {
                if (err != null) {
                    JOptionPane.showMessageDialog(AdminDashboard.this, "❌  " + err, "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(AdminDashboard.this,
                        "✅  Rider #" + id + " updated!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refresh();
                }
            }
        }.execute();
    }

    private void doDeleteRider(int row) {
        int    id   = (int)    ridersModel.getValueAt(row, 0);
        String name = (String) ridersModel.getValueAt(row, 1);
        int confirm = JOptionPane.showConfirmDialog(this,
            "<html><b>Delete Rider: " + name + " (#" + id + ")?</b><br>"
            + "This is permanent. Past orders will show rider as blank.</html>",
            "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;
        new SwingWorker<Void, Void>() {
            String err = null;
            @Override protected Void doInBackground() {
                try { new OrderDAO().deleteRider(id); }
                catch (Exception ex) { err = ex.getMessage(); }
                return null;
            }
            @Override protected void done() {
                if (err != null) {
                    JOptionPane.showMessageDialog(AdminDashboard.this, "❌  " + err, "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(AdminDashboard.this,
                        "✅  Rider deleted.", "Done", JOptionPane.INFORMATION_MESSAGE);
                    refresh();
                }
            }
        }.execute();
    }

    /** Builds the Add/Edit Rider form panel. Pass null status for "Add" mode. */
    private JPanel riderForm(String currentStatus, String name, String phone, String vehicle) {
        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(new Color(243, 250, 249));
        form.setBorder(new EmptyBorder(4, 0, 0, 0));

        JTextField nameF    = styledField(name);
        JTextField phoneF   = styledField(phone);
        JComboBox<String> vehicleBox = new JComboBox<>(new String[]{"Motorcycle","Bicycle","Car","Van"});
        vehicleBox.setSelectedItem(vehicle);
        vehicleBox.setFont(F_BODY); vehicleBox.setBackground(Color.WHITE);

        JComboBox<String> statusBox = new JComboBox<>(new String[]{"Available","On Delivery","Offline"});
        statusBox.setFont(F_BODY); statusBox.setBackground(Color.WHITE);
        if (currentStatus != null) statusBox.setSelectedItem(currentStatus);

        form.add(fLbl("👤  Full Name"));    form.add(Box.createVerticalStrut(4));
        form.add(nameF);                     form.add(Box.createVerticalStrut(10));
        form.add(fLbl("📱  Phone Number")); form.add(Box.createVerticalStrut(4));
        form.add(phoneF);                    form.add(Box.createVerticalStrut(10));
        form.add(fLbl("🏍️  Vehicle Type")); form.add(Box.createVerticalStrut(4));
        form.add(vehicleBox);                form.add(Box.createVerticalStrut(10));
        if (currentStatus != null) {
            form.add(fLbl("🔄  Status"));   form.add(Box.createVerticalStrut(4));
            form.add(statusBox);
        }
        form.setPreferredSize(new Dimension(340, currentStatus != null ? 290 : 230));

        form.putClientProperty("name",    nameF);
        form.putClientProperty("phone",   phoneF);
        form.putClientProperty("vehicle", vehicleBox);
        form.putClientProperty("status",  statusBox);
        return form;
    }

    private JTextField styledField(String val) {
        JTextField f = new JTextField(val);
        f.setFont(F_BODY); f.setBackground(Color.WHITE); f.setForeground(CHARCOAL);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER, 1), new EmptyBorder(9, 12, 9, 12)));
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        f.setAlignmentX(Component.LEFT_ALIGNMENT);
        return f;
    }
    private JLabel fLbl(String t) {
        JLabel l = new JLabel(t); l.setFont(F_LABEL); l.setForeground(WARM_GRAY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT); return l;
    }

    // ── DB helpers ────────────────────────────────────────────────────────────
    private List<Rider> fetchAvailableRiders() { return fetchRiders("Available"); }
    private List<Rider> fetchAllRiders()        { return fetchRiders(null); }

    private List<Rider> fetchRiders(String status) {
        List<Rider> list = new ArrayList<>();
        try {
            String sql = status == null
                ? "SELECT * FROM riders ORDER BY status, full_name"
                : "SELECT * FROM riders WHERE status=? ORDER BY full_name";
            try (PreparedStatement ps = DBConnection.getInstance().getConnection().prepareStatement(sql)) {
                if (status != null) ps.setString(1, status);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Rider r = new Rider();
                        r.setId(rs.getInt("id"));
                        r.setFullName(rs.getString("full_name"));
                        r.setPhone(rs.getString("phone"));
                        r.setVehicleType(rs.getString("vehicle_type"));
                        r.setStatus(parseRiderStatus(rs.getString("status")));
                        r.setTotalDeliveries(rs.getInt("total_deliveries"));
                        r.setRating(rs.getDouble("rating"));
                        list.add(r);
                    }
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    private Rider.Status parseRiderStatus(String s) {
        if (s == null) return Rider.Status.Offline;
        return switch (s.trim()) {
            case "On Delivery" -> Rider.Status.OnDelivery;
            default            -> { try { yield Rider.Status.valueOf(s.replace(" ","")); } catch(Exception e) { yield Rider.Status.Offline; } }
        };
    }

    public void refresh() { loadOrders(); loadRiders(); }

    // ═══════════════════════════════════════════════════════════════════════
    //  CELL RENDERERS & EDITORS
    // ═══════════════════════════════════════════════════════════════════════

    /** Teal pill button renderer (Assign Rider / Edit) */

    static class DeleteBtnRenderer extends JButton implements TableCellRenderer {
        DeleteBtnRenderer() {
            super("Cancel");
            setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(200, 50, 50));
            g2.fillRoundRect(6, 6, getWidth()-12, getHeight()-12, 8, 8);
            g2.setColor(Color.WHITE); g2.setFont(new Font("Trebuchet MS", Font.BOLD, 11));
            FontMetrics fm = g2.getFontMetrics(); String t = "❌  Cancel";
            g2.drawString(t, (getWidth()-fm.stringWidth(t))/2, (getHeight()+fm.getAscent()-fm.getDescent())/2);
            g2.dispose();
        }
        @Override public Component getTableCellRendererComponent(
                JTable t, Object v, boolean s, boolean f, int r, int c) { return this; }
    }

    static class RoseBtnRenderer extends JButton implements TableCellRenderer {
        private final String label;
        RoseBtnRenderer(String label) {
            super(label); this.label = label;
            setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(TEAL);
            g2.fillRoundRect(6, 6, getWidth()-12, getHeight()-12, 8, 8);
            g2.setColor(WHITE); g2.setFont(new Font("Trebuchet MS", Font.BOLD, 11));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(label, (getWidth()-fm.stringWidth(label))/2,
                          (getHeight()+fm.getAscent()-fm.getDescent())/2);
            g2.dispose();
        }
        @Override public Component getTableCellRendererComponent(
                JTable t, Object v, boolean s, boolean f, int r, int c) { return this; }
    }

    /** Red pill button renderer (Delete / Cancel) */
    static class RedBtnRenderer extends JButton implements TableCellRenderer {
        private final String label;
        RedBtnRenderer(String label) {
            super(label); this.label = label;
            setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(195, 40, 40));
            g2.fillRoundRect(6, 6, getWidth()-12, getHeight()-12, 8, 8);
            g2.setColor(WHITE); g2.setFont(new Font("Trebuchet MS", Font.BOLD, 11));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(label, (getWidth()-fm.stringWidth(label))/2,
                          (getHeight()+fm.getAscent()-fm.getDescent())/2);
            g2.dispose();
        }
        @Override public Component getTableCellRendererComponent(
                JTable t, Object v, boolean s, boolean f, int r, int c) { return this; }
    }

    /** Universal pill button editor — works for any color/label combo */
    static class RoseBtnEditor extends DefaultCellEditor {
        private final java.util.function.IntConsumer onClick;
        private final Color  btnColor;
        private final String btnLabel;
        private int currentRow;
        RoseBtnEditor(JCheckBox cb, Color color, String label,
                      java.util.function.IntConsumer onClick) {
            super(cb); this.onClick = onClick;
            this.btnColor = color; this.btnLabel = label;
            setClickCountToStart(1);
        }
        @Override public Component getTableCellEditorComponent(
                JTable t, Object v, boolean s, int r, int c) {
            currentRow = r;
            JButton b = new JButton(btnLabel);
            b.setBackground(btnColor); b.setForeground(WHITE);
            b.setBorderPainted(false); b.setFocusPainted(false);
            b.setFont(new Font("Trebuchet MS", Font.BOLD, 11));
            b.addActionListener(e -> { fireEditingStopped(); onClick.accept(currentRow); });
            return b;
        }
        @Override public Object getCellEditorValue() { return btnLabel; }
    }

    static class StatusCellRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(
                JTable t, Object v, boolean sel, boolean f, int r, int c) {
            JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, sel, f, r, c);
            String s = v != null ? v.toString() : "";
            l.setFont(new Font("Trebuchet MS", Font.BOLD, 11));
            l.setBorder(new EmptyBorder(0, 14, 0, 14));
            l.setForeground(switch (s) {
                case "Pending"        -> AMBER;
                case "Assigned"       -> GREEN;
                case "OutForDelivery" -> BLUE_STAT;
                case "Delivered"      -> new Color(60, 160, 60);
                default               -> WARM_GRAY;
            });
            return l;
        }
    }

    static class RiderStatusRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(
                JTable t, Object v, boolean sel, boolean f, int r, int c) {
            JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, sel, f, r, c);
            String s = v != null ? v.toString() : "";
            l.setFont(new Font("Trebuchet MS", Font.BOLD, 12));
            l.setBorder(new EmptyBorder(0, 14, 0, 14));
            l.setForeground(switch (s) {
                case "Available"   -> GREEN;
                case "On Delivery", "OnDelivery" -> AMBER;
                default            -> WARM_GRAY;
            });
            return l;
        }
    }
}
