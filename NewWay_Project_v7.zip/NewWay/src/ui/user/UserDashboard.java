package ui.user;

import db.DBConnection;
import db.OrderDAO;
import engine.PredictionEngine;
import model.FoodItem;
import model.Order;
import model.User;
import ui.MainFrame;
import ui.DeliveryIcon;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.sql.*;
import java.util.*;
import java.util.List;

public class UserDashboard extends JPanel {

    // ── Palette — Purple + Orange theme ──────────────────────────────────────────
    static final Color WHITE      = Color.WHITE;
    static final Color BG         = new Color(250, 248, 255);
    static final Color TEAL       = new Color(108,  45, 180);   // Purple primary
    static final Color TEAL_DK    = new Color( 80,  28, 140);   // Purple dark
    static final Color TEAL_LIGHT = new Color(245, 238, 255);   // Purple tint
    static final Color ORANGE     = new Color(240, 100,  20);   // Orange
    static final Color ORANGE_LT  = new Color(255, 245, 235);   // Orange light
    // aliases for existing code
    static final Color ROSE       = TEAL;
    static final Color ROSE_DK    = TEAL_DK;
    static final Color ROSE_LIGHT = TEAL_LIGHT;
    static final Color CHARCOAL   = new Color(20,  18,  30);
    static final Color WARM_GRAY  = new Color(110, 100, 125);
    static final Color BORDER     = new Color(220, 210, 235);
    static final Color GOLD       = ORANGE;
    static final Color GREEN      = new Color(32,  130,  72);
    static final Color TAG_BG     = new Color(245, 238, 255);

    // ── Fonts ─────────────────────────────────────────────────────────────────
    static final Font F_BRAND    = new Font("Georgia",      Font.BOLD | Font.ITALIC, 22);
    static final Font F_HERO     = new Font("Georgia",      Font.BOLD | Font.ITALIC, 38);
    static final Font F_HERO_SUB = new Font("Trebuchet MS", Font.PLAIN,               13);
    static final Font F_SECTION  = new Font("Georgia",      Font.BOLD,                20);
    static final Font F_CARD_TTL = new Font("Georgia",      Font.BOLD,                15);
    static final Font F_BODY     = new Font("Trebuchet MS", Font.PLAIN,               13);
    static final Font F_LABEL    = new Font("Trebuchet MS", Font.BOLD,                10);
    static final Font F_SMALL    = new Font("Trebuchet MS", Font.PLAIN,               11);
    static final Font F_BTN      = new Font("Trebuchet MS", Font.BOLD,                13);
    static final Font F_PRICE    = new Font("Georgia",      Font.BOLD,                20);
    static final Font F_NAV      = new Font("Trebuchet MS", Font.PLAIN,               13);
    static final Font F_NAV_ACT  = new Font("Trebuchet MS", Font.BOLD,                13);

    private static final String CARD_MARKET   = "MARKET";
    private static final String CARD_CART     = "CART";
    private static final String CARD_ORDERS   = "ORDERS";
    private static final String CARD_TRACKING = "TRACKING";
    private static final String CARD_SETTINGS = "SETTINGS";

    // Indian city options
    static final String[] CITIES = {"All Locations", "Hyderabad", "Nandyal", "Kurnool"};

    private User currentUser;
    private final Map<Integer, CartItem> cart = new LinkedHashMap<>();
    private final CardLayout innerCards   = new CardLayout();
    private final JPanel     contentArea  = new JPanel(innerCards);

    private JLabel cartCountLbl;
    private JButton activeNavBtn;

    private MarketplacePanel  market;
    CartPanel         cartPanel;
    OrdersPanel       ordersPanel;
    private TrackingPanel     trackingPanel;
    private SettingsPanel     settingsPanel;

    // Cart item holds food info + qty
    static class CartItem {
        int id; String name; java.math.BigDecimal price; int qty;
        CartItem(int id, String name, java.math.BigDecimal price, int qty) {
            this.id=id; this.name=name; this.price=price; this.qty=qty;
        }
    }

    public UserDashboard(User user) {
        this.currentUser = user;
        setLayout(new BorderLayout());
        setBackground(BG);
        buildUI();
    }

    private void buildUI() {
        add(buildNavBar(), BorderLayout.NORTH);
        market        = new MarketplacePanel(this);
        cartPanel     = new CartPanel(this);
        ordersPanel   = new OrdersPanel(this);
        trackingPanel = new TrackingPanel(this);
        contentArea.setBackground(BG);
        contentArea.add(market,        CARD_MARKET);
        contentArea.add(cartPanel,     CARD_CART);
        contentArea.add(ordersPanel,   CARD_ORDERS);
        contentArea.add(trackingPanel, CARD_TRACKING);
        settingsPanel = new SettingsPanel(this);
        contentArea.add(settingsPanel,  CARD_SETTINGS);
        add(contentArea, BorderLayout.CENTER);
        showCard(CARD_MARKET);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  NAVBAR (Bistro Bliss style)
    // ═══════════════════════════════════════════════════════════════════════
    private JPanel buildNavBar() {
        JPanel nav = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                // Slightly warm white
                GradientPaint gp = new GradientPaint(0,0,new Color(255,254,252),0,getHeight(),WHITE);
                g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight());
                // Bottom border with rose accent on left
                g2.setColor(BORDER); g2.drawLine(0,getHeight()-1,getWidth(),getHeight()-1);
                g2.setColor(ROSE); g2.fillRect(0,getHeight()-2,80,2);
                g2.dispose();
            }
        };
        nav.setOpaque(false);
        nav.setPreferredSize(new Dimension(0, 68));
        nav.setBorder(new EmptyBorder(0, 28, 0, 28));

        // Logo
        JPanel logoArea = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        logoArea.setOpaque(false);
        JLabel logoEmoji = new JLabel("🛵"); logoEmoji.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 22));
        JLabel logoText  = new JLabel("NewWay"); logoText.setFont(F_BRAND); logoText.setForeground(CHARCOAL);
        JLabel logoDot   = new JLabel("·"); logoDot.setFont(new Font("Georgia", Font.BOLD, 24)); logoDot.setForeground(ROSE);
        logoArea.add(logoEmoji); logoArea.add(logoText); logoArea.add(logoDot);

        // Nav links
        JPanel links = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
        links.setOpaque(false);
        JButton btnHome   = navLink("  Home",      () -> { market.refresh();      showCard(CARD_MARKET); });
        JButton btnCart   = navLink("  Cart",       () -> { cartPanel.refresh();   showCard(CARD_CART); });
        JButton btnOrders = navLink("  My Orders",  () -> { ordersPanel.refresh(); showCard(CARD_ORDERS); });
        // prepend icons to nav buttons
        btnHome  .setIcon(DeliveryIcon.iconLabel(DeliveryIcon.HOME,   16, WARM_GRAY).getIcon());
        btnCart  .setIcon(DeliveryIcon.iconLabel(DeliveryIcon.CART,   16, WARM_GRAY).getIcon());
        btnOrders.setIcon(DeliveryIcon.iconLabel(DeliveryIcon.ORDERS, 16, WARM_GRAY).getIcon());
        activeNavBtn = btnHome;
        links.add(btnHome); links.add(btnCart); links.add(btnOrders);

        // Right area
        JPanel rightArea = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightArea.setOpaque(false);

        // Cart pill
        JPanel cartPill = pill("🛒 ", null, true);
        cartCountLbl = new JLabel("0"); cartCountLbl.setFont(new Font("Trebuchet MS",Font.BOLD,12)); cartCountLbl.setForeground(ROSE);
        cartPill.add(cartCountLbl);
        cartPill.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        cartPill.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { activeNavBtn = btnCart; cartPanel.refresh(); showCard(CARD_CART); repaint(); }
        });

        // Location pill
        JPanel locPill = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(248, 244, 240)); g2.fillRoundRect(0,0,getWidth(),getHeight(),20,20);
                g2.dispose();
            }
        };
        locPill.setOpaque(false);
        locPill.setBorder(new EmptyBorder(4, 10, 4, 10));
        JLabel locIcon = new JLabel("📍"); locIcon.setFont(new Font("Segoe UI Emoji",Font.PLAIN,13));
        JLabel locName = new JLabel(currentUser!=null ? currentUser.getLocation() : "Hyderabad");
        locName.setFont(new Font("Trebuchet MS",Font.BOLD,12)); locName.setForeground(CHARCOAL);
        locPill.add(locIcon); locPill.add(locName);

        // User pill
        JPanel userPill = pill("👤 " + (currentUser!=null ? currentUser.getFullName().split(" ")[0] : "User"), null, false);

        // Sign Out
        JButton logoutBtn = new JButton("Sign Out") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? ROSE : new Color(240,235,228));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),20,20);
                if (!getModel().isRollover()) { g2.setColor(BORDER); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,20,20); }
                g2.setColor(getModel().isRollover() ? WHITE : WARM_GRAY); g2.setFont(F_SMALL);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        logoutBtn.setContentAreaFilled(false); logoutBtn.setBorderPainted(false); logoutBtn.setFocusPainted(false);
        logoutBtn.setPreferredSize(new Dimension(84, 34));
        logoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> MainFrame.getInstance().logout());

        // Settings button
        JButton settingsBtn = new JButton("⚙") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover()?TEAL_LIGHT:new Color(236,248,246));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),20,20);
                g2.setColor(BORDER); g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,20,20);
                g2.setFont(new Font("Segoe UI Emoji",Font.PLAIN,16));
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString("⚙",(getWidth()-fm.stringWidth("⚙"))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        settingsBtn.setContentAreaFilled(false); settingsBtn.setBorderPainted(false); settingsBtn.setFocusPainted(false);
        settingsBtn.setPreferredSize(new Dimension(38,34)); settingsBtn.setToolTipText("Settings");
        settingsBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        settingsBtn.addActionListener(e -> { settingsPanel.reload(); showCard(CARD_SETTINGS); });

        rightArea.add(cartPill); rightArea.add(locPill); rightArea.add(userPill); rightArea.add(settingsBtn); rightArea.add(logoutBtn);

        nav.add(logoArea,  BorderLayout.WEST);
        nav.add(links,     BorderLayout.CENTER);
        nav.add(rightArea, BorderLayout.EAST);
        return nav;
    }

    private JPanel pill(String text, Color bg, boolean hasBorder) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg!=null ? bg : new Color(248,244,240));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),20,20);
                if (hasBorder) { g2.setColor(BORDER); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,20,20); }
                g2.dispose();
            }
        };
        p.setOpaque(false); p.setBorder(new EmptyBorder(4,10,4,10));
        if (text!=null) {
            JLabel l = new JLabel(text); l.setFont(F_SMALL); l.setForeground(CHARCOAL); p.add(l);
        }
        return p;
    }

    private JButton navLink(String text, Runnable action) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean isActive = this == activeNavBtn;
                boolean hov = getModel().isRollover();
                if (hov && !isActive) {
                    g2.setColor(new Color(248,244,240)); g2.fillRoundRect(2,4,getWidth()-4,getHeight()-8,20,20);
                }
                g2.setColor(isActive ? ROSE : (hov ? CHARCOAL : WARM_GRAY));
                g2.setFont(isActive ? new Font("Trebuchet MS",Font.BOLD,13) : new Font("Trebuchet MS",Font.PLAIN,13));
                FontMetrics fm = g2.getFontMetrics();
                int tx=(getWidth()-fm.stringWidth(getText()))/2;
                int ty=(getHeight()+fm.getAscent()-fm.getDescent())/2;
                g2.drawString(getText(),tx,ty);
                // Active underline
                if (isActive) {
                    g2.setColor(ROSE);
                    int lw=fm.stringWidth(getText());
                    g2.fillRoundRect(tx, getHeight()-6, lw, 3, 3, 3);
                }
                g2.dispose();
            }
        };
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(text.length()*10+22, 40));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e -> { activeNavBtn = b; action.run(); repaint(); });
        return b;
    }

    // ── Public API ────────────────────────────────────────────────────────────
    public void showCard(String c) { innerCards.show(contentArea, c); }
    public void setUser(User u)    { this.currentUser = u; }
    public User getCurrentUser()   { return currentUser; }
    public Map<Integer, CartItem> getCartMap() { return cart; }

    // =====================================================================
    //  SETTINGS DIALOG — Update Profile + Change Password
    // =====================================================================
    private void showSettingsDialog() {
        JDialog dlg = new JDialog(SwingUtilities.getWindowAncestor(this), "⚙  Settings", java.awt.Dialog.ModalityType.APPLICATION_MODAL);
        dlg.setSize(460, 420);
        dlg.setLocationRelativeTo(this);
        dlg.setResizable(false);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(new Color(247,252,252));

        // Header
        JPanel header = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                GradientPaint gp=new GradientPaint(0,0,new Color(10,130,120),getWidth(),0,new Color(6,100,92));
                g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight()); g2.dispose();
            }
        };
        header.setPreferredSize(new Dimension(0,56)); header.setLayout(new FlowLayout(FlowLayout.LEFT,20,14));
        JLabel hi=new JLabel("👤"); hi.setFont(new Font("Segoe UI Emoji",Font.PLAIN,22));
        JLabel ht=new JLabel("Account Settings");
        ht.setFont(new Font("Georgia",Font.BOLD,18)); ht.setForeground(Color.WHITE);
        header.add(hi); header.add(ht);
        root.add(header, BorderLayout.NORTH);

        // Tabs
        CardLayout tcl = new CardLayout();
        JPanel body = new JPanel(tcl);
        body.setBackground(new Color(247,252,252));

        JPanel profilePanel = buildProfilePanel(dlg);
        JPanel passPanel    = buildChangePasswordPanel(dlg);
        body.add(profilePanel, "PROFILE");
        body.add(passPanel,    "PASSWORD");

        JPanel tabs = new JPanel(new GridLayout(1,2,0,0));
        tabs.setBackground(new Color(235,248,246));
        tabs.setPreferredSize(new Dimension(0,38));
        final boolean[] onProfile = {true};

        JButton tp = settingsTabBtn("✏️  Update Profile",  onProfile, true);
        JButton tc = settingsTabBtn("🔒  Change Password", onProfile, false);
        tp.addActionListener(e->{ onProfile[0]=true;  tcl.show(body,"PROFILE");  tabs.repaint(); });
        tc.addActionListener(e->{ onProfile[0]=false; tcl.show(body,"PASSWORD"); tabs.repaint(); });
        tabs.add(tp); tabs.add(tc);

        root.add(tabs, BorderLayout.CENTER);
        // We need to put tabs above body
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(new Color(247,252,252));
        center.add(tabs, BorderLayout.NORTH);
        center.add(body, BorderLayout.CENTER);
        root.add(center, BorderLayout.CENTER);
        dlg.setContentPane(root);
        dlg.setVisible(true);
    }

    private JButton settingsTabBtn(String text, boolean[] flag, boolean iAmProfile) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                boolean active=(flag[0]==iAmProfile);
                g2.setColor(active?Color.WHITE:new Color(230,246,244));
                g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(active?new Color(10,130,120):new Color(180,210,208));
                g2.fillRect(0,getHeight()-3,getWidth(),3);
                g2.setColor(active?new Color(10,130,120):new Color(95,100,108));
                g2.setFont(active?new Font("Trebuchet MS",Font.BOLD,12):new Font("Trebuchet MS",Font.PLAIN,12));
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private JPanel buildProfilePanel(JDialog dlg) {
        JPanel p = new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
        p.setBackground(Color.WHITE); p.setBorder(new EmptyBorder(24,32,24,32));

        JTextField nameF  = styledField(currentUser!=null?currentUser.getFullName():"");
        JTextField emailF = styledField(currentUser!=null?currentUser.getEmail():"");
        emailF.setEditable(false); emailF.setBackground(new Color(248,250,250));
        JTextField phoneF = styledField(currentUser!=null&&currentUser.getPhone()!=null?currentUser.getPhone():"");
        JTextField locF   = styledField(currentUser!=null?currentUser.getLocation():"Hyderabad");

        JLabel msg = new JLabel(" "); msg.setFont(new Font("Trebuchet MS",Font.PLAIN,12)); msg.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton save = actionBtn("💾  Save Changes", new Color(10,130,120));
        save.setAlignmentX(Component.LEFT_ALIGNMENT);
        save.setMaximumSize(new Dimension(Integer.MAX_VALUE,46));
        save.addActionListener(e -> {
            String name=nameF.getText().trim(), phone=phoneF.getText().trim(), loc=locF.getText().trim();
            if(name.isEmpty()){msg.setForeground(new Color(190,60,40));msg.setText("⚠  Name cannot be empty.");return;}
            new SwingWorker<Boolean,Void>(){
                private String err=null;
                @Override protected Boolean doInBackground(){
                    try{
                        java.sql.Connection conn=DBConnection.getInstance().getConnection();
                        try(PreparedStatement ps=conn.prepareStatement("UPDATE users SET full_name=?,phone=?,location=? WHERE id=?")){
                            ps.setString(1,name); ps.setString(2,phone); ps.setString(3,loc.isEmpty()?"Hyderabad":loc);
                            ps.setInt(4,currentUser.getId()); ps.executeUpdate();
                        }
                        return true;
                    }catch(Exception ex){err=ex.getMessage();return false;}
                }
                @Override protected void done(){
                    try{
                        if(get()){
                            currentUser.setFullName(name); currentUser.setPhone(phone); currentUser.setLocation(loc.isEmpty()?"Hyderabad":loc);
                            msg.setForeground(new Color(20,130,100)); msg.setText("✅  Profile updated successfully!");
                        } else { msg.setForeground(new Color(190,60,40)); msg.setText("⚠  "+(err!=null?err:"Update failed.")); }
                    }catch(Exception ex){msg.setText("⚠  Error.");}
                }
            }.execute();
        });

        p.add(fldLbl("👤  FULL NAME")); p.add(Box.createVerticalStrut(5)); p.add(nameF);  p.add(Box.createVerticalStrut(12));
        p.add(fldLbl("✉  EMAIL (cannot change)")); p.add(Box.createVerticalStrut(5)); p.add(emailF); p.add(Box.createVerticalStrut(12));
        p.add(fldLbl("📱  PHONE NUMBER")); p.add(Box.createVerticalStrut(5)); p.add(phoneF); p.add(Box.createVerticalStrut(12));
        p.add(fldLbl("📍  CITY")); p.add(Box.createVerticalStrut(5)); p.add(locF); p.add(Box.createVerticalStrut(12));
        p.add(msg); p.add(Box.createVerticalStrut(8)); p.add(save);
        return p;
    }

    private JPanel buildChangePasswordPanel(JDialog dlg) {
        JPanel p = new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
        p.setBackground(Color.WHITE); p.setBorder(new EmptyBorder(24,32,24,32));

        JPasswordField curF  = new JPasswordField(); styleSettingsInput(curF);
        JPasswordField newF  = new JPasswordField(); styleSettingsInput(newF);
        JPasswordField conf  = new JPasswordField(); styleSettingsInput(conf);

        JLabel msg = new JLabel(" "); msg.setFont(new Font("Trebuchet MS",Font.PLAIN,12)); msg.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton save = actionBtn("🔒  Update Password", new Color(10,130,120));
        save.setAlignmentX(Component.LEFT_ALIGNMENT);
        save.setMaximumSize(new Dimension(Integer.MAX_VALUE,46));
        save.addActionListener(e -> {
            String cur=new String(curF.getPassword()).trim();
            String nw=new String(newF.getPassword()).trim();
            String cn=new String(conf.getPassword()).trim();
            if(cur.isEmpty()||nw.isEmpty()){msg.setForeground(new Color(190,60,40));msg.setText("⚠  All fields required.");return;}
            if(!nw.equals(cn)){msg.setForeground(new Color(190,60,40));msg.setText("⚠  New passwords do not match.");return;}
            if(nw.length()<6){msg.setForeground(new Color(190,60,40));msg.setText("⚠  Password must be at least 6 characters.");return;}
            new SwingWorker<String,Void>(){
                @Override protected String doInBackground(){
                    try{
                        java.sql.Connection conn=DBConnection.getInstance().getConnection();
                        // Verify current
                        try(PreparedStatement ps=conn.prepareStatement("SELECT id FROM users WHERE id=? AND password_hash=?")){
                            ps.setInt(1,currentUser.getId()); ps.setString(2,cur);
                            try(ResultSet rs=ps.executeQuery()){if(!rs.next()) return "WRONG_CURRENT";}
                        }
                        try(PreparedStatement ps=conn.prepareStatement("UPDATE users SET password_hash=? WHERE id=?")){
                            ps.setString(1,nw); ps.setInt(2,currentUser.getId()); ps.executeUpdate();
                        }
                        return "OK";
                    }catch(Exception ex){return "ERR:"+ex.getMessage();}
                }
                @Override protected void done(){
                    try{
                        String result=get();
                        if("OK".equals(result)){msg.setForeground(new Color(20,130,100));msg.setText("✅  Password changed successfully!");curF.setText("");newF.setText("");conf.setText("");}
                        else if("WRONG_CURRENT".equals(result)){msg.setForeground(new Color(190,60,40));msg.setText("⚠  Current password is incorrect.");}
                        else{msg.setForeground(new Color(190,60,40));msg.setText("⚠  "+result.replace("ERR:",""));}
                    }catch(Exception ex){msg.setText("⚠  Error.");}
                }
            }.execute();
        });

        p.add(fldLbl("🔑  CURRENT PASSWORD")); p.add(Box.createVerticalStrut(5)); p.add(curF); p.add(Box.createVerticalStrut(12));
        p.add(fldLbl("🔒  NEW PASSWORD"));     p.add(Box.createVerticalStrut(5)); p.add(newF); p.add(Box.createVerticalStrut(12));
        p.add(fldLbl("🔒  CONFIRM NEW PASSWORD")); p.add(Box.createVerticalStrut(5)); p.add(conf); p.add(Box.createVerticalStrut(12));
        p.add(msg); p.add(Box.createVerticalStrut(8)); p.add(save);
        return p;
    }

    // ── Settings helper widgets ───────────────────────────────────────────────
    private JTextField styledField(String val) {
        JTextField f=new JTextField(val); styleSettingsInput(f); return f;
    }
    private void styleSettingsInput(JComponent c) {
        c.setBackground(new Color(247,252,252)); c.setForeground(new Color(18,22,26));
        if(c instanceof javax.swing.text.JTextComponent tc) tc.setCaretColor(new Color(10,130,120));
        c.setFont(new Font("Trebuchet MS",Font.PLAIN,13));
        c.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(210,228,226),1),new EmptyBorder(10,12,10,12)));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE,46)); c.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.addFocusListener(new FocusAdapter(){
            public void focusGained(FocusEvent e){c.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(10,130,120),2),new EmptyBorder(9,11,9,11)));c.setBackground(Color.WHITE);}
            public void focusLost(FocusEvent e){c.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(210,228,226),1),new EmptyBorder(10,12,10,12)));c.setBackground(new Color(247,252,252));}
        });
    }
    private JLabel fldLbl(String t){JLabel l=new JLabel(t);l.setFont(new Font("Trebuchet MS",Font.BOLD,9));l.setForeground(new Color(95,100,108));l.setAlignmentX(Component.LEFT_ALIGNMENT);return l;}
    private JButton actionBtn(String text, Color bg){
        final boolean[] h={false};
        JButton b=new JButton(text){
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g.create(); g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp=new GradientPaint(0,0,h[0]?bg.darker():bg,0,getHeight(),bg.darker());
                g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.setColor(new Color(255,255,255,25)); g2.fillRoundRect(2,2,getWidth()-4,getHeight()/2-2,8,8);
                g2.setColor(Color.WHITE); g2.setFont(new Font("Trebuchet MS",Font.BOLD,13));
                FontMetrics fm=g2.getFontMetrics(); g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        b.addMouseListener(new MouseAdapter(){public void mouseEntered(MouseEvent e){h[0]=true;b.repaint();}public void mouseExited(MouseEvent e){h[0]=false;b.repaint();}});
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); return b;
    }

    public void addToCart(int id, String name, java.math.BigDecimal price) {
        cart.merge(id, new CartItem(id,name,price,1),
            (old, n) -> { old.qty++; return old; });
        cartCountLbl.setText(String.valueOf(cart.values().stream().mapToInt(ci->ci.qty).sum()));
    }
    public void removeFromCart(int id) {
        cart.remove(id);
        cartCountLbl.setText(String.valueOf(cart.values().stream().mapToInt(ci->ci.qty).sum()));
    }
    public void clearCart() {
        cart.clear(); cartCountLbl.setText("0");
    }
    public void trackOrder(int id)  { trackingPanel.loadOrder(id); showCard(CARD_TRACKING); }
    public void refresh()           { if (market != null) market.refresh(); }

    // ═══════════════════════════════════════════════════════════════════════
    //  MARKETPLACE
    // ═══════════════════════════════════════════════════════════════════════
    static class MarketplacePanel extends JPanel {
        private final UserDashboard p;
        private JPanel       grid;
        private JTextField   searchField;
        private JComboBox<String> cityBox;
        private JPanel       categoryRow;
        private String activeCategory = "All";

        MarketplacePanel(UserDashboard parent) {
            this.p = parent; setBackground(BG); setLayout(new BorderLayout()); buildUI(); refresh();
        }

        private void buildUI() {
            // ── Hero ──────────────────────────────────────────────────────
            JPanel hero = new JPanel(new BorderLayout()) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    // Rich multi-stop gradient
                    GradientPaint gp = new GradientPaint(0,0,new Color(38,18,10),getWidth(),getHeight(),new Color(16,8,5));
                    g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight());
                    // Rose glow left-center
                    RadialGradientPaint r1=new RadialGradientPaint(new Point2D.Float(getWidth()*0.22f,getHeight()*0.5f),getWidth()*0.38f,
                        new float[]{0f,1f},new Color[]{new Color(155,34,57,80),new Color(0,0,0,0)});
                    g2.setPaint(r1); g2.fillRect(0,0,getWidth(),getHeight());
                    // Amber glow right
                    RadialGradientPaint r2=new RadialGradientPaint(new Point2D.Float(getWidth()*0.88f,getHeight()*0.3f),getWidth()*0.3f,
                        new float[]{0f,1f},new Color[]{new Color(220,150,30,55),new Color(0,0,0,0)});
                    g2.setPaint(r2); g2.fillRect(0,0,getWidth(),getHeight());
                    // Large food emojis right side (decorative)
                    g2.setFont(new Font("Segoe UI Emoji",Font.PLAIN,48));
                    String[] ef={"🍛","🫕","🥗","🍔","☕"};
                    int[] ex={getWidth()-270,getWidth()-170,getWidth()-310,getWidth()-130,getWidth()-220};
                    int[] ey={30,55,100,20,80};
                    for(int i=0;i<ef.length;i++){g2.setColor(new Color(255,255,255,18));g2.drawString(ef[i],ex[i],ey[i]);}
                    // Right fade overlay
                    GradientPaint ov=new GradientPaint(getWidth()*0.5f,0,new Color(0,0,0,0),getWidth(),0,new Color(12,6,3,200));
                    g2.setPaint(ov); g2.fillRect(0,0,getWidth(),getHeight());
                    g2.dispose();
                }
            };
            hero.setPreferredSize(new Dimension(0, 170));
            hero.setBorder(new EmptyBorder(0, 36, 0, 36));

            JPanel heroTxt = new JPanel(); heroTxt.setLayout(new BoxLayout(heroTxt,BoxLayout.Y_AXIS)); heroTxt.setOpaque(false);
            JLabel h1 = new JLabel("Best food for your taste"); h1.setFont(F_HERO); h1.setForeground(WHITE); h1.setAlignmentX(Component.LEFT_ALIGNMENT);
            JLabel h2 = new JLabel("Order from Hyderabad · Nandyal · Kurnool's finest restaurants"); h2.setFont(F_HERO_SUB); h2.setForeground(new Color(200,185,165)); h2.setAlignmentX(Component.LEFT_ALIGNMENT);
            heroTxt.add(Box.createVerticalGlue()); heroTxt.add(h1); heroTxt.add(Box.createVerticalStrut(8)); heroTxt.add(h2); heroTxt.add(Box.createVerticalGlue());
            hero.add(heroTxt, BorderLayout.WEST);

            // ── Search + City filter ───────────────────────────────────────
            JPanel filterBar = new JPanel(new BorderLayout(16, 0)) {
                @Override protected void paintComponent(Graphics g) {
                    g.setColor(WHITE); g.fillRect(0,0,getWidth(),getHeight());
                    g.setColor(BORDER); g.drawLine(0,getHeight()-1,getWidth(),getHeight()-1);
                }
            };
            filterBar.setOpaque(false);
            filterBar.setBorder(new EmptyBorder(12, 28, 12, 28));

            // Search box
            JPanel srchBox = new JPanel(new BorderLayout(8,0)) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(new Color(248,246,242)); g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                    g2.setColor(BORDER); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,8,8); g2.dispose();
                }
            };
            srchBox.setOpaque(false); srchBox.setBorder(new EmptyBorder(9,12,9,12));
            srchBox.setPreferredSize(new Dimension(300,44));
            JLabel si = new JLabel("🔍"); si.setFont(new Font("Segoe UI Emoji",Font.PLAIN,14));
            searchField = new JTextField(); searchField.setOpaque(false); searchField.setBorder(null);
            searchField.setFont(F_BODY); searchField.setForeground(CHARCOAL);
            searchField.addActionListener(e -> refresh());
            srchBox.add(si,BorderLayout.WEST); srchBox.add(searchField,BorderLayout.CENTER);

            // City selector
            JPanel cityWrap = new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); cityWrap.setOpaque(false);
            JLabel ci = new JLabel("📍"); ci.setFont(new Font("Segoe UI Emoji",Font.PLAIN,14));
            cityBox = new JComboBox<>(CITIES);
            // Pre-select user's city
            if (p.currentUser != null) {
                for (int i=0;i<CITIES.length;i++) if(CITIES[i].equals(p.currentUser.getLocation())) { cityBox.setSelectedIndex(i); break; }
            }
            cityBox.setBackground(WHITE); cityBox.setFont(F_BODY);
            cityBox.addActionListener(e -> refresh());
            cityWrap.add(ci); cityWrap.add(cityBox);

            // Search button
            JButton srchBtn = new JButton("Search") {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(getModel().isRollover()?ROSE_DK:ROSE); g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                    g2.setColor(WHITE); g2.setFont(F_BTN); FontMetrics fm=g2.getFontMetrics();
                    g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2); g2.dispose();
                }
            };
            srchBtn.setContentAreaFilled(false); srchBtn.setBorderPainted(false); srchBtn.setFocusPainted(false);
            srchBtn.setPreferredSize(new Dimension(90,44)); srchBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            srchBtn.addActionListener(e -> refresh());

            JPanel filterLeft = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0)); filterLeft.setOpaque(false);
            filterLeft.add(srchBox); filterLeft.add(cityWrap); filterLeft.add(srchBtn);
            filterBar.add(filterLeft, BorderLayout.WEST);

            // ── Category chips ─────────────────────────────────────────────
            categoryRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
            categoryRow.setBackground(BG);
            categoryRow.setBorder(new EmptyBorder(4, 24, 4, 24));
            for (String cat : new String[]{"All","Biryani","Breakfast","Curry","Snacks","Meals","Starter","Grill","Dessert","Beverages"}) {
                categoryRow.add(chip(cat));
            }

            JPanel topSection = new JPanel(new BorderLayout());
            topSection.setOpaque(false);
            topSection.add(hero,        BorderLayout.NORTH);
            topSection.add(filterBar,   BorderLayout.CENTER);
            topSection.add(categoryRow, BorderLayout.SOUTH);

            // ── Grid ──────────────────────────────────────────────────────
            grid = new JPanel(new GridLayout(0,3,16,16));
            grid.setBackground(BG); grid.setBorder(new EmptyBorder(16,24,24,24));

            JScrollPane scroll = new JScrollPane(grid);
            scroll.setBorder(BorderFactory.createEmptyBorder());
            scroll.getViewport().setBackground(BG);
            scroll.getVerticalScrollBar().setUnitIncrement(20);

            add(topSection, BorderLayout.NORTH);
            add(scroll,     BorderLayout.CENTER);
        }

        private JButton chip(String cat) {
            JButton b = new JButton(cat) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    boolean on = cat.equals(activeCategory);
                    g2.setColor(on ? ROSE : WHITE); g2.fillRoundRect(0,0,getWidth(),getHeight(),getHeight(),getHeight());
                    if (!on) { g2.setColor(BORDER); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,getHeight(),getHeight()); }
                    g2.setColor(on ? WHITE : WARM_GRAY);
                    g2.setFont(on ? new Font("Trebuchet MS",Font.BOLD,12) : new Font("Trebuchet MS",Font.PLAIN,12));
                    FontMetrics fm=g2.getFontMetrics();
                    String disp = catEmoji(cat)+" "+cat;
                    g2.drawString(disp,(getWidth()-fm.stringWidth(disp))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                    g2.dispose();
                }
            };
            b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
            String disp = catEmoji(cat)+" "+cat;
            b.setPreferredSize(new Dimension(disp.length()*8+20, 32));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.addActionListener(e -> { activeCategory = cat; categoryRow.repaint(); refresh(); });
            return b;
        }

        private String catEmoji(String c) {
            return switch(c) {
                case "Biryani"   -> "🍛"; case "Breakfast" -> "🥞";
                case "Curry"     -> "🍲"; case "Snacks"    -> "🫓";
                case "Meals"     -> "🍱"; case "Starter"   -> "🍗";
                case "Grill"     -> "🔥"; case "Dessert"   -> "🍮";
                case "Beverages" -> "☕"; default           -> "🍽️";
            };
        }

        void refresh() {
            grid.removeAll();
            grid.setLayout(new BorderLayout());
            JLabel loading = new JLabel("Loading menu…", SwingConstants.CENTER);
            loading.setFont(new Font("Georgia",Font.ITALIC,15)); loading.setForeground(new Color(180,172,160));
            grid.add(loading, BorderLayout.CENTER);
            grid.revalidate(); grid.repaint();

            String city   = Objects.toString(cityBox.getSelectedItem(),"All Locations");
            String search = searchField.getText().trim();
            String cat    = activeCategory;

            new SwingWorker<List<FoodItem>,Void>() {
                @Override protected List<FoodItem> doInBackground() throws Exception { return load(city,search,cat); }
                @Override protected void done() {
                    try {
                        List<FoodItem> items = get();
                        grid.setLayout(new GridLayout(0,3,16,16));
                        grid.removeAll();
                        if (items.isEmpty()) {
                            grid.setLayout(new BorderLayout());
                            JLabel el = new JLabel(
                                "<html><center>🍽️<br><br>No items found for <b>" + city + "</b>.<br><small>Try a different city or category.</small></center></html>",
                                SwingConstants.CENTER);
                            el.setFont(new Font("Georgia",Font.ITALIC,15)); el.setForeground(new Color(180,172,160));
                            grid.add(el, BorderLayout.CENTER);
                        } else {
                            for (FoodItem fi : items) grid.add(buildCard(fi));
                        }
                        grid.revalidate(); grid.repaint();
                    } catch(Exception ex){ ex.printStackTrace(); }
                }
            }.execute();
        }

        private List<FoodItem> load(String city, String search, String cat) throws Exception {
            StringBuilder sql = new StringBuilder(
                "SELECT f.*, r.name AS restaurant_name, r.location AS restaurant_location " +
                "FROM food_items f JOIN restaurants r ON f.restaurant_id=r.id WHERE f.is_available=1 ");
            if (!"All Locations".equals(city))
                sql.append("AND r.location='").append(city.replace("'","''")).append("' ");
            if (!search.isEmpty())
                sql.append("AND f.name LIKE '%").append(search.replace("'","''")).append("%' ");
            if (!"All".equals(cat))
                sql.append("AND f.category='").append(cat.replace("'","''")).append("' ");
            sql.append("ORDER BY f.rating DESC, f.price ASC");
            List<FoodItem> list = new ArrayList<>();
            java.sql.Connection conn = DBConnection.getInstance().getConnection();
            try(Statement st=conn.createStatement();
                ResultSet rs=st.executeQuery(sql.toString())) {
                while(rs.next()) {
                    FoodItem fi=new FoodItem();
                    fi.setId(rs.getInt("id")); fi.setName(rs.getString("name"));
                    fi.setRestaurantName(rs.getString("restaurant_name"));
                    fi.setPrice(rs.getBigDecimal("price")); fi.setRating(rs.getDouble("rating"));
                    fi.setImagePath(rs.getString("image_path")); fi.setCategory(rs.getString("category"));
                    fi.setDescription(rs.getString("description"));
                    list.add(fi);
                }
            }
            return list;
        }

        private JPanel buildCard(FoodItem fi) {
            final boolean[] hovered = {false};
            JPanel card = new JPanel(new BorderLayout()) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    // Elevated shadow on hover
                    int shadowAlpha = hovered[0] ? 22 : 10;
                    int shadowOff   = hovered[0] ? 6  : 3;
                    g2.setColor(new Color(0,0,0,shadowAlpha));
                    g2.fillRoundRect(shadowOff, shadowOff, getWidth()-shadowOff, getHeight()-shadowOff, 16, 16);
                    // Card background
                    if (hovered[0]) {
                        GradientPaint gp = new GradientPaint(0,0,WHITE,0,getHeight(),new Color(255,252,250));
                        g2.setPaint(gp);
                    } else {
                        g2.setColor(WHITE);
                    }
                    g2.fillRoundRect(0,0,getWidth()-shadowOff,getHeight()-shadowOff,16,16);
                    // Hover rose top accent
                    if (hovered[0]) {
                        g2.setColor(new Color(155,34,57,180));
                        g2.fillRoundRect(0,0,getWidth()-shadowOff,5,16,16);
                        g2.fillRect(0,0,getWidth()-shadowOff,5);
                    }
                    g2.dispose();
                }
            };
            card.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { hovered[0]=true;  card.repaint(); }
                public void mouseExited (MouseEvent e) { hovered[0]=false; card.repaint(); }
            });
            card.setOpaque(false); card.setBorder(new EmptyBorder(0,0,6,6));

            // Image zone — rich gradient bg with radial warm light
            JPanel imgZone = new JPanel(new BorderLayout()) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    GradientPaint gp=new GradientPaint(0,0,new Color(255,246,234),getWidth(),getHeight(),new Color(238,220,195));
                    g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight());
                    // Warm radial highlight
                    RadialGradientPaint rl = new RadialGradientPaint(
                        new Point2D.Float(getWidth()*0.35f, getHeight()*0.3f), getWidth()*0.55f,
                        new float[]{0f,1f}, new Color[]{new Color(255,210,140,60), new Color(0,0,0,0)});
                    g2.setPaint(rl); g2.fillRect(0,0,getWidth(),getHeight());
                    g2.dispose();
                }
            };
            imgZone.setOpaque(false); imgZone.setPreferredSize(new Dimension(0,155));

            JLabel imgLbl = new JLabel();
            imgLbl.setHorizontalAlignment(SwingConstants.CENTER);
            imgLbl.setVerticalAlignment(SwingConstants.CENTER);
            boolean loaded = false;
            if (fi.getImagePath()!=null&&!fi.getImagePath().isEmpty()) {
                try {
                    ImageIcon ic=new ImageIcon(fi.getImagePath());
                    if(ic.getIconWidth()>0) { imgLbl.setIcon(new ImageIcon(ic.getImage().getScaledInstance(260,148,Image.SCALE_SMOOTH))); loaded=true; }
                } catch(Exception ignored) {}
            }
            if (!loaded) { imgLbl.setText(catBigEmoji(fi.getCategory())); imgLbl.setFont(new Font("Segoe UI Emoji",Font.PLAIN,60)); }
            imgZone.add(imgLbl, BorderLayout.CENTER);

            // Category + rating overlay on image bottom
            JPanel imgBottom = new JPanel(new BorderLayout());
            imgBottom.setOpaque(false);
            JPanel catWrap = new JPanel(new FlowLayout(FlowLayout.LEFT,6,4)); catWrap.setOpaque(false);
            JLabel catChip = new JLabel("  "+(fi.getCategory()!=null?fi.getCategory():"Food")+"  ");
            catChip.setFont(new Font("Trebuchet MS",Font.BOLD,9));
            catChip.setForeground(WHITE); catChip.setBackground(ROSE); catChip.setOpaque(true);
            catChip.setBorder(new EmptyBorder(3,4,3,4));
            catWrap.add(catChip);

            // Star rating chip
            JLabel ratingChip = new JLabel(String.format("★ %.1f",fi.getRating()));
            ratingChip.setFont(new Font("Trebuchet MS",Font.BOLD,10));
            ratingChip.setForeground(new Color(80,60,10)); ratingChip.setBackground(new Color(255,240,160));
            ratingChip.setOpaque(true); ratingChip.setBorder(new EmptyBorder(3,6,3,6));
            JPanel ratWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT,6,4)); ratWrap.setOpaque(false); ratWrap.add(ratingChip);

            imgBottom.add(catWrap, BorderLayout.WEST); imgBottom.add(ratWrap, BorderLayout.EAST);
            imgZone.add(imgBottom, BorderLayout.SOUTH);

            // Card body
            JPanel body = new JPanel(); body.setLayout(new BoxLayout(body,BoxLayout.Y_AXIS));
            body.setBackground(WHITE); body.setBorder(new EmptyBorder(12,14,10,14));

            JLabel nameL = new JLabel(fi.getName()); nameL.setFont(F_CARD_TTL); nameL.setForeground(CHARCOAL); nameL.setAlignmentX(Component.LEFT_ALIGNMENT);
            JLabel restoL = new JLabel("🏪  "+fi.getRestaurantName()); restoL.setFont(F_SMALL); restoL.setForeground(WARM_GRAY); restoL.setAlignmentX(Component.LEFT_ALIGNMENT);

            // Description snippet
            String desc = fi.getDescription()!=null?fi.getDescription():"";
            JLabel descL = new JLabel("<html><div style='width:200px;color:#999;font-size:10px'>"
                +(desc.length()>52?desc.substring(0,50)+"…":desc)+"</div></html>");
            descL.setAlignmentX(Component.LEFT_ALIGNMENT);

            // Price + ETA row
            JPanel priceRow = new JPanel(new BorderLayout()); priceRow.setBackground(WHITE);
            priceRow.setAlignmentX(Component.LEFT_ALIGNMENT); priceRow.setMaximumSize(new Dimension(Integer.MAX_VALUE,32));
            JLabel priceL = new JLabel("₹" + fi.getPrice().toPlainString()); priceL.setFont(F_PRICE); priceL.setForeground(ROSE);
            // Estimated delivery time chip
            int etaMin = 20 + (int)(Math.random()*20);
            JLabel etaChip = new JLabel("⏱ ~"+etaMin+" min");
            etaChip.setFont(new Font("Trebuchet MS",Font.BOLD,9));
            etaChip.setForeground(WARM_GRAY);
            priceRow.add(priceL, BorderLayout.WEST); priceRow.add(etaChip, BorderLayout.EAST);

            // Button row — "🛒 Quick Order" + "🛍 Add to Cart"
            JPanel btnRow = new JPanel(new GridLayout(1,2,6,0));
            btnRow.setBackground(WHITE); btnRow.setAlignmentX(Component.LEFT_ALIGNMENT);
            btnRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

            // Quick Order button — orange accent
            JButton quickBtn = new JButton("🛒 Order Now") {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    Color fill = getModel().isRollover()?ORANGE.darker():ORANGE;
                    GradientPaint gp=new GradientPaint(0,0,fill,0,getHeight(),fill.darker());
                    g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                    g2.setColor(new Color(255,255,255,22)); g2.fillRoundRect(2,2,getWidth()-4,getHeight()/2-2,6,6);
                    g2.setColor(WHITE); g2.setFont(new Font("Trebuchet MS",Font.BOLD,11));
                    FontMetrics fm=g2.getFontMetrics();
                    g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                    g2.dispose();
                }
            };
            quickBtn.setContentAreaFilled(false); quickBtn.setBorderPainted(false); quickBtn.setFocusPainted(false);
            quickBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            quickBtn.addActionListener(e -> {
                p.addToCart(fi.getId(), fi.getName(), fi.getPrice());
                p.cartPanel.refresh(); p.showCard(CARD_CART);
            });
            quickBtn.setIcon(DeliveryIcon.iconLabel(DeliveryIcon.RIDER, 14, Color.WHITE).getIcon());

            // Add to Cart button
            final boolean[] added = {false};
            JButton addBtn = new JButton("🛍 Add") {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    Color fill = added[0] ? new Color(22,130,72) : (getModel().isRollover()?ROSE_DK:ROSE);
                    GradientPaint gp=new GradientPaint(0,0,fill,0,getHeight(),fill.darker());
                    g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                    g2.setColor(new Color(255,255,255,22)); g2.fillRoundRect(2,2,getWidth()-4,getHeight()/2-2,6,6);
                    g2.setColor(WHITE); g2.setFont(new Font("Trebuchet MS",Font.BOLD,11));
                    FontMetrics fm=g2.getFontMetrics();
                    g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                    g2.dispose();
                }
            };
            addBtn.setContentAreaFilled(false); addBtn.setBorderPainted(false); addBtn.setFocusPainted(false);
            addBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addBtn.addActionListener(e -> {
                p.addToCart(fi.getId(), fi.getName(), fi.getPrice());
                added[0]=true; addBtn.setText("✔ Added"); addBtn.repaint();
                javax.swing.Timer t=new javax.swing.Timer(1600,ev->{added[0]=false;addBtn.setText("🛍 Add");addBtn.repaint();}); t.setRepeats(false); t.start();
            });

            btnRow.add(quickBtn); btnRow.add(addBtn);

            body.add(nameL); body.add(Box.createVerticalStrut(2));
            body.add(restoL); body.add(Box.createVerticalStrut(3));
            body.add(descL); body.add(Box.createVerticalStrut(6));
            body.add(priceRow); body.add(Box.createVerticalStrut(8));
            body.add(btnRow);

            card.add(imgZone, BorderLayout.NORTH);
            card.add(body,    BorderLayout.CENTER);
            return card;
        }

        private String catBigEmoji(String c) {
            if(c==null) return "🍽️";
            return switch(c) {
                case "Biryani"->"🍛"; case "Breakfast"->"🥞"; case "Curry"->"🍲";
                case "Snacks"->"🫓"; case "Meals"->"🍱"; case "Starter"->"🍗";
                case "Grill"->"🔥"; case "Dessert"->"🍮"; case "Beverages"->"☕";
                default->"🍽️";
            };
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CART
    // ═══════════════════════════════════════════════════════════════════════
    static class CartPanel extends JPanel {
        private final UserDashboard p;
        private JPanel itemsList;
        private JLabel totalLabel;

        CartPanel(UserDashboard parent) {
            this.p = parent; setBackground(BG); setLayout(new BorderLayout()); buildUI();
        }
        private void buildUI() {
            JPanel hdr = new JPanel(new BorderLayout()) {
                @Override protected void paintComponent(Graphics g) {
                    g.setColor(WHITE); g.fillRect(0,0,getWidth(),getHeight());
                    g.setColor(BORDER); g.drawLine(0,getHeight()-1,getWidth(),getHeight()-1);
                }
            };
            hdr.setOpaque(false); hdr.setBorder(new EmptyBorder(18,28,18,28));
            JPanel cartHdg = DeliveryIcon.headingPanel(DeliveryIcon.CART, 28, ROSE,
                "  Shopping Cart", new Font("Georgia",Font.BOLD,26), CHARCOAL);
            cartHdg.setOpaque(false);
            hdr.add(cartHdg, BorderLayout.WEST);
            itemsList = new JPanel(); itemsList.setLayout(new BoxLayout(itemsList,BoxLayout.Y_AXIS));
            itemsList.setBackground(BG); itemsList.setBorder(new EmptyBorder(20,28,20,28));
            JScrollPane sc = new JScrollPane(itemsList);
            sc.setBorder(BorderFactory.createEmptyBorder()); sc.getViewport().setBackground(BG);

            JPanel footer = new JPanel(new BorderLayout()) {
                @Override protected void paintComponent(Graphics g) {
                    g.setColor(WHITE); g.fillRect(0,0,getWidth(),getHeight());
                    g.setColor(BORDER); g.drawLine(0,0,getWidth(),0);
                }
            };
            footer.setOpaque(false); footer.setBorder(new EmptyBorder(18,28,18,28));

            totalLabel = new JLabel("🛒  Total: ₹0.00"); totalLabel.setFont(new Font("Georgia",Font.BOLD,22)); totalLabel.setForeground(CHARCOAL);

            JButton ob = new JButton("🚀  Place Order") {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    GradientPaint gp=new GradientPaint(0,0,getModel().isRollover()?ROSE_DK:ROSE,0,getHeight(),ROSE_DK);
                    g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                    g2.setColor(new Color(255,255,255,25)); g2.fillRoundRect(2,2,getWidth()-4,getHeight()/2-2,10,10);
                    g2.setColor(WHITE); g2.setFont(new Font("Trebuchet MS",Font.BOLD,14));
                    FontMetrics fm=g2.getFontMetrics();
                    g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2); g2.dispose();
                }
            };
            ob.setContentAreaFilled(false); ob.setBorderPainted(false); ob.setFocusPainted(false);
            ob.setPreferredSize(new Dimension(200,52)); ob.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            ob.addActionListener(e -> checkout());

            footer.add(totalLabel,BorderLayout.WEST); footer.add(ob,BorderLayout.EAST);
            add(hdr,BorderLayout.NORTH); add(sc,BorderLayout.CENTER); add(footer,BorderLayout.SOUTH);
        }

        void refresh() {
            itemsList.removeAll();
            double total = 0;
            if (p.getCartMap().isEmpty()) {
                JPanel ep = new JPanel(new GridBagLayout()); ep.setBackground(BG);
                JLabel el = new JLabel("<html><center><span style='font-size:36px'>🛒</span><br><br><b>Your cart is empty</b><br><small style='color:#aaa'>Browse the menu and add something delicious!</small></center></html>", SwingConstants.CENTER);
                el.setFont(new Font("Georgia",Font.ITALIC,16)); el.setForeground(new Color(180,172,162));
                ep.add(el); ep.setPreferredSize(new Dimension(400,260)); itemsList.add(ep);
            } else {
                for (CartItem ci : p.getCartMap().values()) {
                    total += ci.price.doubleValue() * ci.qty;
                    itemsList.add(buildRow(ci)); itemsList.add(Box.createVerticalStrut(10));
                }
            }
            totalLabel.setText("🛒  Total: ₹" + String.format("%,.2f", total));
            itemsList.revalidate(); itemsList.repaint();
        }

        private JPanel buildRow(CartItem ci) {
            JPanel row = new JPanel(new BorderLayout(14,0));
            row.setBackground(WHITE);
            row.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER,1),new EmptyBorder(14,18,14,18)));
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE,74));

            JPanel left = new JPanel(); left.setLayout(new BoxLayout(left,BoxLayout.Y_AXIS)); left.setBackground(WHITE);
            JLabel nameL = new JLabel("🍽️  "+ci.name); nameL.setFont(new Font("Trebuchet MS",Font.BOLD,14)); nameL.setForeground(CHARCOAL);
            JLabel qty   = new JLabel("🔢  "+ci.qty+"  ×  ₹"+ci.price.toPlainString()+"   =   ₹"+String.format("%.2f",ci.price.doubleValue()*ci.qty));
            qty.setFont(F_SMALL); qty.setForeground(WARM_GRAY);
            left.add(nameL); left.add(Box.createVerticalStrut(3)); left.add(qty);

            JButton rm = new JButton("🗑  Remove") {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(getModel().isRollover()?new Color(220,235,250):ROSE_LIGHT);
                    g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                    g2.setColor(ROSE); g2.setStroke(new BasicStroke(1.2f));
                    g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,8,8);
                    g2.setColor(ROSE); g2.setFont(new Font("Trebuchet MS",Font.BOLD,11));
                    FontMetrics fm=g2.getFontMetrics();
                    g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                    g2.dispose();
                }
            };
            rm.setContentAreaFilled(false); rm.setBorderPainted(false); rm.setFocusPainted(false);
            rm.setPreferredSize(new Dimension(100,34)); rm.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            rm.addActionListener(e -> { p.removeFromCart(ci.id); refresh(); });

            row.add(left, BorderLayout.CENTER); row.add(rm, BorderLayout.EAST);
            return row;
        }

        private String catEmoji(String c) { return "🍽️"; }

        private void checkout() {
            if (p.getCartMap().isEmpty()) {
                JOptionPane.showMessageDialog(this, "🛒  Your cart is empty!", "Cart Empty", JOptionPane.INFORMATION_MESSAGE); return;
            }
            // ── Address dialog ────────────────────────────────────────
            JPanel addrPanel = new JPanel(); addrPanel.setLayout(new BoxLayout(addrPanel,BoxLayout.Y_AXIS));
            addrPanel.setBackground(new Color(243,250,249)); addrPanel.setBorder(new EmptyBorder(6,0,0,0));

            String savedAddr = p.getCurrentUser().getAddress()!=null ? p.getCurrentUser().getAddress()
                             : p.getCurrentUser().getLocation()!=null ? p.getCurrentUser().getLocation() : "";

            JLabel hdr = new JLabel("📦  Confirm Delivery Details");
            hdr.setFont(new Font("Georgia",Font.BOLD,17)); hdr.setForeground(new Color(18,22,26));
            hdr.setAlignmentX(Component.LEFT_ALIGNMENT);

            JLabel addrLbl = new JLabel("📍  Delivery Address");
            addrLbl.setFont(new Font("Trebuchet MS",Font.BOLD,10)); addrLbl.setForeground(new Color(95,100,108));
            addrLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

            JTextField addrField = new JTextField(savedAddr, 32);
            addrField.setFont(new Font("Trebuchet MS",Font.PLAIN,13));
            addrField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(10,130,120),1),
                new EmptyBorder(9,12,9,12)));
            addrField.setBackground(Color.WHITE);
            addrField.setAlignmentX(Component.LEFT_ALIGNMENT);

            JLabel noteLbl = new JLabel("📝  Special Notes (optional)");
            noteLbl.setFont(new Font("Trebuchet MS",Font.BOLD,10)); noteLbl.setForeground(new Color(95,100,108));
            noteLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

            JTextField noteField = new JTextField(28);
            noteField.setFont(new Font("Trebuchet MS",Font.PLAIN,13));
            noteField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200,228,224),1),
                new EmptyBorder(9,12,9,12)));
            noteField.setBackground(Color.WHITE);
            noteField.setAlignmentX(Component.LEFT_ALIGNMENT);

            double total = p.getCartMap().values().stream().mapToDouble(ci->ci.price.doubleValue()*ci.qty).sum();
            int itemCount = p.getCartMap().values().stream().mapToInt(ci->ci.qty).sum();
            JLabel summaryLbl = new JLabel(String.format("🛒  %d item(s)   |   💰  Total: ₹%,.2f", itemCount, total));
            summaryLbl.setFont(new Font("Trebuchet MS",Font.BOLD,12));
            summaryLbl.setForeground(new Color(10,130,120));
            summaryLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

            addrPanel.add(hdr);            addrPanel.add(Box.createVerticalStrut(14));
            addrPanel.add(summaryLbl);     addrPanel.add(Box.createVerticalStrut(16));
            addrPanel.add(addrLbl);        addrPanel.add(Box.createVerticalStrut(5));
            addrPanel.add(addrField);      addrPanel.add(Box.createVerticalStrut(12));
            addrPanel.add(noteLbl);        addrPanel.add(Box.createVerticalStrut(5));
            addrPanel.add(noteField);      addrPanel.add(Box.createVerticalStrut(4));
            addrPanel.setPreferredSize(new Dimension(420, 230));

            String[] options = {"🚀  Place Order", "✕  Cancel"};
            int result = JOptionPane.showOptionDialog(this, addrPanel, "NewWay — Place Order",
                JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            if (result != 0) return;  // cancelled

            String addr = addrField.getText().trim();
            String note = noteField.getText().trim();
            if (addr.isEmpty()) { JOptionPane.showMessageDialog(this,"⚠  Please enter a delivery address."); return; }

            // Save address on user object for next time
            p.getCurrentUser().setAddress(addr);

            try {
                int oid = new OrderDAO().placeOrder(p.getCurrentUser().getId(), total, addr, 3.5, 1.2, 0, note);
                p.clearCart(); refresh();

                // Show animated success dialog
                JPanel confirmPanel = new JPanel();
                confirmPanel.setLayout(new BoxLayout(confirmPanel,BoxLayout.Y_AXIS));
                confirmPanel.setBackground(WHITE);
                confirmPanel.setBorder(new EmptyBorder(10,16,10,16));

                JLabel icon = new JLabel("🎉", SwingConstants.CENTER);
                icon.setFont(new Font("Segoe UI Emoji",Font.PLAIN,44));
                icon.setAlignmentX(Component.CENTER_ALIGNMENT);

                JLabel cl1 = new JLabel("Order Placed Successfully!", SwingConstants.CENTER);
                cl1.setFont(new Font("Georgia",Font.BOLD,20)); cl1.setForeground(new Color(108,45,180));
                cl1.setAlignmentX(Component.CENTER_ALIGNMENT);

                JLabel cl2 = new JLabel("Order #"+oid+"   |   Rs."+String.format("%,.2f",total), SwingConstants.CENTER);
                cl2.setFont(new Font("Trebuchet MS",Font.BOLD,14)); cl2.setForeground(new Color(60,60,80));
                cl2.setAlignmentX(Component.CENTER_ALIGNMENT);

                JLabel cl3 = new JLabel("Delivering to: "+addr, SwingConstants.CENTER);
                cl3.setFont(new Font("Trebuchet MS",Font.PLAIN,12)); cl3.setForeground(new Color(110,100,125));
                cl3.setAlignmentX(Component.CENTER_ALIGNMENT);

                JLabel cl4 = new JLabel("Rider will be assigned shortly", SwingConstants.CENTER);
                cl4.setFont(new Font("Trebuchet MS",Font.ITALIC,12)); cl4.setForeground(new Color(130,120,145));
                cl4.setAlignmentX(Component.CENTER_ALIGNMENT);

                // Separator
                JPanel sep = new JPanel(); sep.setBackground(new Color(220,210,235));
                sep.setMaximumSize(new Dimension(Integer.MAX_VALUE,1)); sep.setPreferredSize(new Dimension(300,1));
                sep.setAlignmentX(Component.CENTER_ALIGNMENT);

                // "View My Orders" button
                JButton goOrders = new JButton("  View My Orders  >");
                goOrders.setFont(new Font("Trebuchet MS",Font.BOLD,13));
                goOrders.setBackground(new Color(108,45,180)); goOrders.setForeground(Color.WHITE);
                goOrders.setFocusPainted(false); goOrders.setBorderPainted(false); goOrders.setOpaque(true);
                goOrders.setAlignmentX(Component.CENTER_ALIGNMENT);
                goOrders.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

                confirmPanel.add(icon);         confirmPanel.add(Box.createVerticalStrut(8));
                confirmPanel.add(cl1);          confirmPanel.add(Box.createVerticalStrut(6));
                confirmPanel.add(cl2);          confirmPanel.add(Box.createVerticalStrut(4));
                confirmPanel.add(cl3);          confirmPanel.add(Box.createVerticalStrut(4));
                confirmPanel.add(cl4);          confirmPanel.add(Box.createVerticalStrut(14));
                confirmPanel.add(sep);          confirmPanel.add(Box.createVerticalStrut(12));
                confirmPanel.add(goOrders);

                // Use JDialog so we can close it programmatically
                JDialog dlg = new JDialog(SwingUtilities.getWindowAncestor(this), "Order Confirmed!", Dialog.ModalityType.APPLICATION_MODAL);
                dlg.setContentPane(confirmPanel);
                dlg.setUndecorated(false);
                dlg.pack(); dlg.setLocationRelativeTo(this);

                goOrders.addActionListener(ev -> {
                    dlg.dispose();
                    p.ordersPanel.refresh();
                    p.showCard(CARD_ORDERS);
                });

                dlg.setVisible(true);  // blocks until closed

            } catch(Exception ex) {
                JOptionPane.showMessageDialog(this,"  Error: "+ex.getMessage(),"DB Error",JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  MY ORDERS
    // ═══════════════════════════════════════════════════════════════════════
    static class OrdersPanel extends JPanel {
        private final UserDashboard p;
        private JPanel list;

        OrdersPanel(UserDashboard parent) {
            this.p=parent; setBackground(BG); setLayout(new BorderLayout()); buildUI();
        }
        private void buildUI() {
            JPanel hdr=new JPanel(new BorderLayout()) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(WHITE); g2.fillRect(0,0,getWidth(),getHeight());
                    // Purple gradient bottom border
                    GradientPaint gp=new GradientPaint(0,getHeight()-2,ROSE,getWidth()*0.4f,getHeight()-2,BORDER);
                    g2.setPaint(gp); g2.fillRect(0,getHeight()-2,getWidth(),2);
                    g2.dispose();
                }
            };
            hdr.setOpaque(false); hdr.setBorder(new EmptyBorder(18,28,18,28));
            JPanel ordHdg = DeliveryIcon.headingPanel(DeliveryIcon.ORDERS, 28, ROSE,
                "  My Orders", new Font("Georgia",Font.BOLD,26), CHARCOAL);
            ordHdg.setOpaque(false);

            // "🗑 Clear History" button — deletes all Cancelled/Delivered orders
            JButton clearHistBtn = new JButton("🗑  Clear History") {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    Color base = new Color(195,40,40);
                    g2.setColor(getModel().isRollover()?base.darker():base);
                    g2.fillRoundRect(0,0,getWidth(),getHeight(),20,20);
                    g2.setColor(new Color(255,255,255,18)); g2.fillRoundRect(2,2,getWidth()-4,getHeight()/2-2,18,18);
                    g2.setColor(WHITE); g2.setFont(new Font("Trebuchet MS",Font.BOLD,12));
                    FontMetrics fm=g2.getFontMetrics();
                    g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                    g2.dispose();
                }
            };
            clearHistBtn.setContentAreaFilled(false); clearHistBtn.setBorderPainted(false); clearHistBtn.setFocusPainted(false);
            clearHistBtn.setPreferredSize(new Dimension(148,36)); clearHistBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            clearHistBtn.addActionListener(e -> {
                int confirm=JOptionPane.showConfirmDialog(p,
                    "<html><b>🗑  Clear Order History?</b><br><small>This removes all Delivered and Cancelled orders from your history.<br>Active (Pending/Assigned) orders are kept.</small></html>",
                    "Confirm Clear History",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
                if(confirm!=JOptionPane.YES_OPTION) return;
                new SwingWorker<Integer,Void>(){
                    String err=null;
                    @Override protected Integer doInBackground(){
                        try{
                            java.sql.Connection conn=DBConnection.getInstance().getConnection();
                            conn.setAutoCommit(false);
                            try{
                                // Step 1: delete order_items for completed/cancelled orders of this user
                                try(PreparedStatement ps=conn.prepareStatement(
                                    "DELETE oi FROM order_items oi "+
                                    "JOIN orders o ON oi.order_id=o.id "+
                                    "WHERE o.user_id=? AND o.status IN ('Delivered','Cancelled')")){
                                    ps.setInt(1,p.getCurrentUser().getId()); ps.executeUpdate();
                                }
                                // Step 2: delete the orders themselves
                                int n;
                                try(PreparedStatement ps=conn.prepareStatement(
                                    "DELETE FROM orders WHERE user_id=? AND status IN ('Delivered','Cancelled')")){
                                    ps.setInt(1,p.getCurrentUser().getId()); n=ps.executeUpdate();
                                }
                                conn.commit(); conn.setAutoCommit(true);
                                return n;
                            }catch(Exception ex){conn.rollback();conn.setAutoCommit(true);throw ex;}
                        }catch(Exception ex){err=ex.getMessage();return 0;}
                    }
                    @Override protected void done(){
                        try{
                            int n=get();
                            if(err!=null) JOptionPane.showMessageDialog(p,"⚠ "+err,"Error",JOptionPane.ERROR_MESSAGE);
                            else { JOptionPane.showMessageDialog(p,"✅  Removed "+n+" order(s) from history.","History Cleared",JOptionPane.INFORMATION_MESSAGE); refresh(); }
                        }catch(Exception ex){ex.printStackTrace();}
                    }
                }.execute();
            });

            hdr.add(ordHdg, BorderLayout.WEST); hdr.add(clearHistBtn,BorderLayout.EAST);
            list=new JPanel(); list.setLayout(new BoxLayout(list,BoxLayout.Y_AXIS));
            list.setBackground(BG); list.setBorder(new EmptyBorder(20,28,20,28));
            JScrollPane sc=new JScrollPane(list);
            sc.setBorder(BorderFactory.createEmptyBorder()); sc.getViewport().setBackground(BG);
            add(hdr,BorderLayout.NORTH); add(sc,BorderLayout.CENTER);
        }
        void refresh() {
            list.removeAll();
            new SwingWorker<List<Order>,Void>() {
                @Override protected List<Order> doInBackground() throws Exception { return new OrderDAO().getOrdersByUserWithHistory(p.getCurrentUser().getId()); }
                @Override protected void done() {
                    try {
                        List<Order> orders=get();
                        if(orders.isEmpty()) {
                            JLabel el=new JLabel("<html><center>📦<br><br>No orders yet.<br><small style='color:#aaa'>Start exploring the menu!</small></center></html>",SwingConstants.CENTER);
                            el.setFont(new Font("Georgia",Font.ITALIC,15)); el.setForeground(new Color(180,172,162)); list.add(el);
                        } else { for(Order o:orders){ list.add(buildRow(o)); list.add(Box.createVerticalStrut(10)); } }
                        list.revalidate(); list.repaint();
                    } catch(Exception ex){ ex.printStackTrace(); }
                }
            }.execute();
        }
        private JPanel buildRow(Order o) {
            // ── Delivery timing logic ──────────────────────────────────────────
            boolean deliveredFast = false;
            long minutesAgo = 0;
            if (o.getStatus()==Order.Status.Delivered && o.getPlacedAt()!=null) {
                minutesAgo = java.time.Duration.between(o.getPlacedAt(), java.time.LocalDateTime.now()).toMinutes();
                deliveredFast = minutesAgo <= 25;
            }
            final boolean isFastDelivery = deliveredFast;

            // ── Status colors & symbols ────────────────────────────────────────
            Color sc = switch(o.getStatus()){
                case Delivered      -> isFastDelivery ? new Color(20,160,80) : GREEN;
                case Cancelled      -> new Color(190,45,45);
                case OutForDelivery -> new Color(200,110,10);
                case Assigned       -> new Color(108,45,180);
                default             -> ROSE;
            };
            String statusSymbol = switch(o.getStatus()){
                case Delivered      -> isFastDelivery ? "⚡✅" : "✅";
                case Cancelled      -> "❌";
                case OutForDelivery -> "🏍️";
                case Assigned       -> "🔔";
                default             -> "⏳";
            };
            String statusText = o.getStatus().name().replace("OutForDelivery","Out for Delivery");

            // ── Card panel ─────────────────────────────────────────────────────
            JPanel row = new JPanel(new BorderLayout(16,0)) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    // Special glow for fast-delivered orders
                    if (isFastDelivery) {
                        g2.setColor(new Color(20,160,80,12));
                        g2.fillRoundRect(0,0,getWidth(),getHeight(),14,14);
                        g2.setColor(new Color(20,160,80,60));
                        g2.setStroke(new BasicStroke(1.5f));
                        g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,14,14);
                        // Top green stripe
                        GradientPaint gp=new GradientPaint(0,0,new Color(20,160,80,140),getWidth()*0.5f,0,new Color(20,160,80,0));
                        g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),4,6,6);
                    } else {
                        g2.setColor(WHITE); g2.fillRoundRect(0,0,getWidth(),getHeight(),14,14);
                        g2.setColor(BORDER); g2.setStroke(new BasicStroke(1f));
                        g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,14,14);
                    }
                    g2.dispose();
                }
            };
            row.setOpaque(false);
            row.setBorder(new EmptyBorder(16,20,16,20));
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, isFastDelivery ? 110 : 100));

            // ── LEFT panel ────────────────────────────────────────────────────
            JPanel left=new JPanel(); left.setLayout(new BoxLayout(left,BoxLayout.Y_AXIS)); left.setOpaque(false);

            // Order ID + fast badge
            JPanel idRow = new JPanel(new FlowLayout(FlowLayout.LEFT,6,0)); idRow.setOpaque(false); idRow.setAlignmentX(Component.LEFT_ALIGNMENT);
            JLabel oid=new JLabel("🧾  Order #"+o.getId());
            oid.setFont(isFastDelivery ? new Font("Georgia",Font.BOLD|Font.ITALIC,17) : new Font("Georgia",Font.BOLD,16));
            oid.setForeground(isFastDelivery ? new Color(16,130,65) : CHARCOAL);
            idRow.add(oid);
            if (isFastDelivery) {
                JLabel badge = new JLabel(" ⚡ Fast Delivery ");
                badge.setFont(new Font("Trebuchet MS",Font.BOLD,9));
                badge.setForeground(WHITE); badge.setBackground(new Color(20,160,80)); badge.setOpaque(true);
                badge.setBorder(new EmptyBorder(2,5,2,5));
                idRow.add(badge);
            }

            JLabel addr=new JLabel("📍  "+(o.getDeliveryAddress()!=null ? o.getDeliveryAddress() : "—"));
            addr.setFont(F_SMALL); addr.setForeground(WARM_GRAY); addr.setAlignmentX(Component.LEFT_ALIGNMENT);

            JLabel dt=new JLabel("🕐  "+(o.getPlacedAt()!=null?o.getPlacedAt().toString().substring(0,16):"—")
                +(o.getStatus()==Order.Status.Delivered && minutesAgo>0 ? "  ("+minutesAgo+" min ago)" : ""));
            dt.setFont(isFastDelivery ? new Font("Trebuchet MS",Font.ITALIC,11) : F_SMALL);
            dt.setForeground(isFastDelivery ? new Color(20,140,70) : WARM_GRAY); dt.setAlignmentX(Component.LEFT_ALIGNMENT);

            // Predicted ETA if available
            if (o.getPredictedTimeMin()!=null && o.getStatus()!=Order.Status.Cancelled) {
                JLabel eta=new JLabel("⏱️  ETA: "+o.getPredictedTimeMin()+" min");
                eta.setFont(new Font("Trebuchet MS",Font.BOLD,10)); eta.setForeground(new Color(108,45,180)); eta.setAlignmentX(Component.LEFT_ALIGNMENT);
                left.add(idRow); left.add(addr); left.add(dt); left.add(eta);
            } else {
                left.add(idRow); left.add(addr); left.add(dt);
            }

            // ── RIGHT panel ───────────────────────────────────────────────────
            JPanel right=new JPanel(); right.setLayout(new BoxLayout(right,BoxLayout.Y_AXIS)); right.setOpaque(false);

            // Price label
            JLabel price=new JLabel("💰  ₹"+o.getTotalPrice());
            price.setFont(isFastDelivery ? new Font("Georgia",Font.BOLD|Font.ITALIC,19) : new Font("Georgia",Font.BOLD,18));
            price.setForeground(isFastDelivery ? new Color(20,150,70) : ROSE);
            price.setAlignmentX(Component.RIGHT_ALIGNMENT);

            // Status label
            JLabel status=new JLabel(statusSymbol+"  "+statusText);
            status.setFont(new Font("Trebuchet MS",Font.BOLD, isFastDelivery?12:11));
            status.setForeground(sc); status.setAlignmentX(Component.RIGHT_ALIGNMENT);

            // Button row
            JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT,6,4)); btnRow.setOpaque(false);

            // 🔍 Track button
            JButton tb = actionBtn("  Track", ROSE, ROSE_DK);
            tb.setIcon(DeliveryIcon.iconLabel(DeliveryIcon.TRACK, 14, Color.WHITE).getIcon());
            tb.setEnabled(o.isActive()); tb.addActionListener(e->p.trackOrder(o.getId()));

            // Action button: Cancel / Delete
            boolean cancellable = o.getStatus()==Order.Status.Pending;
            boolean deletable   = o.getStatus()==Order.Status.Cancelled || o.getStatus()==Order.Status.Delivered;
            String  actLabel    = cancellable ? "  Cancel" : (deletable ? "  Delete" : "—");
            JButton actBtn = actionBtn(actLabel, new Color(195,40,40), new Color(150,20,20));
            if (deletable)   actBtn.setIcon(DeliveryIcon.iconLabel(DeliveryIcon.TRASH,  14, Color.WHITE).getIcon());
            if (cancellable) actBtn.setIcon(DeliveryIcon.iconLabel(DeliveryIcon.TRASH,  14, Color.WHITE).getIcon());
            actBtn.setEnabled(cancellable || deletable);
            if (!cancellable && !deletable) actBtn.setVisible(false);
            actBtn.addActionListener(e -> {
                String msg = deletable
                    ? "<html><b>🗑  Remove Order #"+o.getId()+" from history?</b><br>₹"+o.getTotalPrice()+" ("+statusText+")</html>"
                    : "<html><b>✕  Cancel Order #"+o.getId()+"?</b><br>₹"+o.getTotalPrice()
                        +"<br><small>Placed: "+(o.getPlacedAt()!=null?o.getPlacedAt().toString().substring(0,16):"")+"</small></html>";
                int confirm=JOptionPane.showConfirmDialog(p,msg,
                    deletable?"Confirm Delete":"Confirm Cancel",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
                if(confirm!=JOptionPane.YES_OPTION) return;
                new SwingWorker<Void,Void>(){
                    String err=null;
                    @Override protected Void doInBackground(){
                        try{
                            if(deletable){
                                java.sql.Connection conn=DBConnection.getInstance().getConnection();
                                conn.setAutoCommit(false);
                                try{
                                    try(PreparedStatement ps=conn.prepareStatement(
                                        "DELETE FROM order_items WHERE order_id=?")){
                                        ps.setInt(1,o.getId()); ps.executeUpdate();
                                    }
                                    try(PreparedStatement ps=conn.prepareStatement(
                                        "DELETE FROM orders WHERE id=? AND user_id=?")){
                                        ps.setInt(1,o.getId()); ps.setInt(2,p.getCurrentUser().getId()); ps.executeUpdate();
                                    }
                                    conn.commit(); conn.setAutoCommit(true);
                                }catch(Exception ex){conn.rollback();conn.setAutoCommit(true);throw ex;}
                            } else { new OrderDAO().cancelOrder(o.getId()); }
                        }catch(Exception ex){err=ex.getMessage();}
                        return null;
                    }
                    @Override protected void done(){
                        if(err!=null) JOptionPane.showMessageDialog(p,"⚠  "+err,"Error",JOptionPane.ERROR_MESSAGE);
                        else { JOptionPane.showMessageDialog(p,
                            deletable?"🗑  Order removed from history.":"✅  Order #"+o.getId()+" cancelled.",
                            deletable?"Deleted":"Cancelled",JOptionPane.INFORMATION_MESSAGE); refresh(); }
                    }
                }.execute();
            });

            btnRow.add(tb);
            if (cancellable || deletable) btnRow.add(actBtn);

            right.add(price); right.add(Box.createVerticalStrut(2)); right.add(status);
            right.add(Box.createVerticalGlue()); right.add(btnRow);

            row.add(left,BorderLayout.CENTER); row.add(right,BorderLayout.EAST);
            return row;
        }

        // Helper — styled action button
        private JButton actionBtn(String text, Color fill, Color fillHov) {
            JButton b = new JButton(text) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    Color c = !isEnabled() ? new Color(205,200,215) : (getModel().isRollover()?fillHov:fill);
                    g2.setColor(c); g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                    g2.setColor(new Color(255,255,255,20)); g2.fillRoundRect(2,2,getWidth()-4,getHeight()/2-2,6,6);
                    g2.setColor(WHITE); g2.setFont(new Font("Trebuchet MS",Font.BOLD,11));
                    FontMetrics fm=g2.getFontMetrics();
                    g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                    g2.dispose();
                }
            };
            b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
            b.setPreferredSize(new Dimension(96,30)); b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            return b;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  TRACKING
    // ═══════════════════════════════════════════════════════════════════════
    static class TrackingPanel extends JPanel {
        private final UserDashboard p;
        private JLabel statusLbl, riderLbl, etaLbl, explainLbl, orderLbl;

        TrackingPanel(UserDashboard parent) {
            this.p=parent; setBackground(BG); setLayout(new GridBagLayout()); buildUI();
        }
        private void buildUI() {
            JPanel card=new JPanel() {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(WHITE); g2.fillRoundRect(0,0,getWidth(),getHeight(),16,16);
                    GradientPaint gp=new GradientPaint(0,0,TEAL,getWidth()*0.55f,0,new Color(8,160,148));
                    g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),8,6,6);
                    g2.setColor(BORDER); g2.setStroke(new BasicStroke(1f)); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,16,16);
                    g2.dispose();
                }
            };
            card.setLayout(new BoxLayout(card,BoxLayout.Y_AXIS));
            card.setOpaque(false); card.setBorder(new EmptyBorder(32,48,32,48));
            card.setPreferredSize(new Dimension(540,480));

            JLabel icon=cLbl("🛵",new Font("Segoe UI Emoji",Font.PLAIN,52),CHARCOAL);
            JLabel title=cLbl("Live Order Tracking",new Font("Georgia",Font.BOLD,28),CHARCOAL);
            orderLbl =cLbl("—",F_SMALL,WARM_GRAY);
            statusLbl=cLbl("Status: —",new Font("Trebuchet MS",Font.BOLD,14),WARM_GRAY);
            riderLbl =cLbl("Rider: —",F_BODY,WARM_GRAY);

            // ETA box
            JPanel etaBox=new JPanel() {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(TEAL_LIGHT); g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                    g2.setColor(new Color(170,220,216)); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,12,12); g2.dispose();
                }
            };
            etaBox.setLayout(new BoxLayout(etaBox,BoxLayout.Y_AXIS));
            etaBox.setOpaque(false); etaBox.setBorder(new EmptyBorder(14,40,14,40));
            etaBox.setAlignmentX(Component.CENTER_ALIGNMENT); etaBox.setMaximumSize(new Dimension(300,110));
            JLabel etaHead=cLbl("PREDICTED DELIVERY TIME",F_LABEL,WARM_GRAY);
            etaLbl=cLbl("— min",new Font("Georgia",Font.BOLD,42),TEAL);
            etaBox.add(etaHead); etaBox.add(etaLbl);

            explainLbl=new JLabel("<html><center><i>Prediction breakdown will appear here</i></center></html>",SwingConstants.CENTER);
            explainLbl.setFont(F_SMALL); explainLbl.setForeground(new Color(160,150,138)); explainLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

            JButton back=new JButton("← Back to Orders") {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create(); g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(getModel().isRollover()?new Color(240,234,226):new Color(248,244,238));
                    g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8); g2.setColor(BORDER); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,8,8);
                    g2.setColor(WARM_GRAY); g2.setFont(F_BODY); FontMetrics fm=g2.getFontMetrics();
                    g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2); g2.dispose();
                }
            };
            back.setContentAreaFilled(false); back.setBorderPainted(false); back.setFocusPainted(false);
            back.setPreferredSize(new Dimension(180,40)); back.setMaximumSize(new Dimension(180,40));
            back.setAlignmentX(Component.CENTER_ALIGNMENT); back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            back.addActionListener(e->p.showCard("ORDERS"));

            for (JLabel l : new JLabel[]{icon,title,orderLbl,statusLbl,riderLbl}) l.setAlignmentX(Component.CENTER_ALIGNMENT);
            card.add(icon); card.add(Box.createVerticalStrut(6)); card.add(title);
            card.add(Box.createVerticalStrut(4)); card.add(orderLbl);
            card.add(Box.createVerticalStrut(18)); card.add(statusLbl);
            card.add(Box.createVerticalStrut(6));  card.add(riderLbl);
            card.add(Box.createVerticalStrut(18)); card.add(etaBox);
            card.add(Box.createVerticalStrut(14)); card.add(explainLbl);
            card.add(Box.createVerticalStrut(22)); card.add(back);
            add(card);
        }
        private JLabel cLbl(String t,Font f,Color c){ JLabel l=new JLabel(t,SwingConstants.CENTER); l.setFont(f); l.setForeground(c); return l; }

        void loadOrder(int id) {
            orderLbl.setText("Order #"+id); etaLbl.setText("…"); statusLbl.setText("Loading…");
            new SwingWorker<Order,Void>() {
                @Override protected Order doInBackground() throws Exception { return new OrderDAO().findById(id).orElse(null); }
                @Override protected void done() {
                    try {
                        Order o=get(); if(o==null) return;
                        statusLbl.setText("Status:  "+o.getStatus().name().replace("OutForDelivery","Out for Delivery"));
                        riderLbl.setText("Rider:  "+(o.getRiderName()!=null?"🏍️ "+o.getRiderName():"⏳ Awaiting assignment…"));
                        etaLbl.setText(o.getPredictedTimeMin()!=null?o.getPredictedTimeMin()+" min":"—");
                        String exp=PredictionEngine.getInstance().explainPrediction(o.getDistanceKm(),o.getTrafficFactor(),o.getWeatherCode());
                        explainLbl.setText("<html><center style='font-size:11px;color:#888'>"+exp.replace("\n","<br>")+"</center></html>");
                    } catch(Exception ex){ ex.printStackTrace(); }
                }
            }.execute();
        }
    }
    // ═══════════════════════════════════════════════════════════════════════
    //  SETTINGS PANEL
    // ═══════════════════════════════════════════════════════════════════════
    static class SettingsPanel extends JPanel {
        private final UserDashboard p;

        SettingsPanel(UserDashboard parent) {
            this.p = parent;
            setBackground(BG);
            setLayout(new BorderLayout());
            buildUI();
        }

        private void buildUI() {
            // Header bar
            JPanel hdr = new JPanel(new BorderLayout()) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setColor(WHITE); g2.fillRect(0,0,getWidth(),getHeight());
                    g2.setColor(BORDER); g2.drawLine(0,getHeight()-1,getWidth(),getHeight()-1);
                    g2.setColor(TEAL); g2.fillRect(0,getHeight()-2,80,2);
                    g2.dispose();
                }
            };
            hdr.setOpaque(false); hdr.setBorder(new EmptyBorder(20,28,20,28));
            JLabel title = new JLabel("⚙️  Settings");
            title.setFont(new Font("Georgia",Font.BOLD,26)); title.setForeground(CHARCOAL);
            JButton backBtn = buildSmallBtn("← Back", TEAL, WHITE);
            backBtn.addActionListener(e -> p.showCard("MARKET"));
            hdr.add(title, BorderLayout.WEST); hdr.add(backBtn, BorderLayout.EAST);

            // Content
            JPanel content = new JPanel();
            content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
            content.setBackground(BG);
            content.setBorder(new EmptyBorder(32, 0, 32, 0));

            JScrollPane scroll = new JScrollPane(content);
            scroll.setBorder(BorderFactory.createEmptyBorder());
            scroll.getViewport().setBackground(BG);

            // Profile card
            content.add(Box.createHorizontalGlue());
            content.add(buildCard(
                "👤  Profile Information",
                "Update your name, phone number and city",
                "✏️  Edit Profile",
                TEAL,
                () -> showUpdateProfileDialog()
            ));
            content.add(Box.createVerticalStrut(16));
            content.add(buildCard(
                "🔒  Change Password",
                "Update your account password securely",
                "🔑  Change Password",
                new Color(10,130,120),
                () -> showChangePasswordDialog()
            ));
            content.add(Box.createVerticalStrut(16));
            content.add(buildCard(
                "🚪  Sign Out",
                "Log out of your NewWay account",
                "Sign Out",
                new Color(190,60,40),
                () -> MainFrame.getInstance().logout()
            ));

            add(hdr, BorderLayout.NORTH);
            add(scroll, BorderLayout.CENTER);
        }

        void reload() { /* refresh user info if needed */ }

        private JPanel buildCard(String title, String desc, String btnText, Color btnColor, Runnable action) {
            JPanel card = new JPanel(new BorderLayout(16,0)) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(new Color(0,0,0,8)); g2.fillRoundRect(3,3,getWidth()-3,getHeight()-3,14,14);
                    g2.setColor(WHITE); g2.fillRoundRect(0,0,getWidth()-4,getHeight()-4,14,14);
                    g2.dispose();
                }
            };
            card.setOpaque(false);
            card.setBorder(new EmptyBorder(20,24,20,24));
            card.setMaximumSize(new Dimension(600, 90));
            card.setAlignmentX(Component.CENTER_ALIGNMENT);

            JPanel text = new JPanel(); text.setLayout(new BoxLayout(text,BoxLayout.Y_AXIS)); text.setOpaque(false);
            JLabel tl = new JLabel(title); tl.setFont(new Font("Georgia",Font.BOLD,16)); tl.setForeground(CHARCOAL);
            JLabel dl = new JLabel(desc);  dl.setFont(new Font("Trebuchet MS",Font.PLAIN,12)); dl.setForeground(WARM_GRAY);
            text.add(tl); text.add(Box.createVerticalStrut(3)); text.add(dl);

            JButton btn = buildSmallBtn(btnText, btnColor, WHITE);
            btn.addActionListener(e -> action.run());

            card.add(text, BorderLayout.CENTER); card.add(btn, BorderLayout.EAST);
            return card;
        }

        private JButton buildSmallBtn(String text, Color bg, Color fg) {
            final boolean[] h={false};
            JButton b = new JButton(text) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(h[0]?bg.darker():bg);
                    g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                    g2.setColor(new Color(255,255,255,25));
                    g2.fillRoundRect(2,2,getWidth()-4,getHeight()/2-2,6,6);
                    g2.setColor(fg); g2.setFont(new Font("Trebuchet MS",Font.BOLD,12));
                    FontMetrics fm=g2.getFontMetrics();
                    g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                    g2.dispose();
                }
            };
            b.addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){h[0]=true; b.repaint();}
                public void mouseExited (MouseEvent e){h[0]=false;b.repaint();}
            });
            b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
            b.setPreferredSize(new Dimension(Math.max(120, text.length()*10+24), 38));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            return b;
        }

        // ── Update Profile Dialog ─────────────────────────────────────────
        private void showUpdateProfileDialog() {
            User u = p.getCurrentUser();

            JPanel form = new JPanel(); form.setLayout(new BoxLayout(form,BoxLayout.Y_AXIS));
            form.setBackground(new Color(243,250,249)); form.setBorder(new EmptyBorder(4,0,0,0));

            JLabel dlgTitle = new JLabel("✏️  Update Profile");
            dlgTitle.setFont(new Font("Georgia",Font.BOLD,17)); dlgTitle.setForeground(CHARCOAL);
            dlgTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

            JTextField nameF = styledField(u.getFullName()!=null?u.getFullName():"");
            JTextField emailF = styledField(u.getEmail()!=null?u.getEmail():"");
            emailF.setEditable(false); emailF.setBackground(new Color(235,248,246));
            JTextField phoneF = styledField(u.getPhone()!=null?u.getPhone():"");
            JTextField cityF  = styledField(u.getLocation()!=null?u.getLocation():"Hyderabad");

            form.add(dlgTitle);              form.add(Box.createVerticalStrut(14));
            form.add(fLbl("👤  Full Name")); form.add(Box.createVerticalStrut(5));
            form.add(nameF);                 form.add(Box.createVerticalStrut(10));
            form.add(fLbl("✉  Email (read-only)")); form.add(Box.createVerticalStrut(5));
            form.add(emailF);                form.add(Box.createVerticalStrut(10));
            form.add(fLbl("📱  Phone Number")); form.add(Box.createVerticalStrut(5));
            form.add(phoneF);                form.add(Box.createVerticalStrut(10));
            form.add(fLbl("📍  City"));      form.add(Box.createVerticalStrut(5));
            form.add(cityF);                 form.add(Box.createVerticalStrut(4));
            form.setPreferredSize(new Dimension(380, 310));

            String[] options = {"💾  Save Changes", "✕  Cancel"};
            int res = JOptionPane.showOptionDialog(this, form, "NewWay — Edit Profile",
                JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            if (res != 0) return;
            String name  = nameF.getText().trim();
            String phone = phoneF.getText().trim();
            String city  = cityF.getText().trim();
            if (name.isEmpty()) { JOptionPane.showMessageDialog(this,"⚠  Name cannot be empty."); return; }

            new SwingWorker<Boolean,Void>() {
                String err = null;
                @Override protected Boolean doInBackground() {
                    try {
                        java.sql.Connection conn = DBConnection.getInstance().getConnection();
                        try (PreparedStatement ps = conn.prepareStatement(
                            "UPDATE users SET full_name=?, phone=?, location=? WHERE id=?")) {
                            ps.setString(1,name); ps.setString(2,phone);
                            ps.setString(3,city.isEmpty()?"Hyderabad":city); ps.setInt(4,u.getId());
                            ps.executeUpdate();
                        }
                        u.setFullName(name); u.setPhone(phone);
                        u.setLocation(city.isEmpty()?"Hyderabad":city);
                        return true;
                    } catch(Exception ex){ err=ex.getMessage(); return false; }
                }
                @Override protected void done() {
                    try {
                        if(get()) {
                            JOptionPane.showMessageDialog(SettingsPanel.this,
                                "✅  Profile updated successfully!","Success",JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(SettingsPanel.this,
                                "❌  Error: "+err,"Update Failed",JOptionPane.ERROR_MESSAGE);
                        }
                    } catch(Exception ex){ ex.printStackTrace(); }
                }
            }.execute();
        }

        // ── Change Password Dialog ────────────────────────────────────────
        private void showChangePasswordDialog() {
            User u = p.getCurrentUser();

            JPanel form = new JPanel(); form.setLayout(new BoxLayout(form,BoxLayout.Y_AXIS));
            form.setBackground(new Color(243,250,249)); form.setBorder(new EmptyBorder(4,0,0,0));

            JLabel dlgTitle = new JLabel("🔒  Change Password");
            dlgTitle.setFont(new Font("Georgia",Font.BOLD,17)); dlgTitle.setForeground(CHARCOAL);
            dlgTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

            JPasswordField oldP  = styledPassField();
            JPasswordField newP  = styledPassField();
            JPasswordField newP2 = styledPassField();

            form.add(dlgTitle);                  form.add(Box.createVerticalStrut(14));
            form.add(fLbl("🔑  Current Password")); form.add(Box.createVerticalStrut(5));
            form.add(oldP);                       form.add(Box.createVerticalStrut(10));
            form.add(fLbl("🔒  New Password"));   form.add(Box.createVerticalStrut(5));
            form.add(newP);                       form.add(Box.createVerticalStrut(10));
            form.add(fLbl("🔒  Confirm New Password")); form.add(Box.createVerticalStrut(5));
            form.add(newP2);                      form.add(Box.createVerticalStrut(4));
            form.setPreferredSize(new Dimension(360, 240));

            String[] options = {"🔑  Update Password", "✕  Cancel"};
            int res = JOptionPane.showOptionDialog(this, form, "NewWay — Change Password",
                JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            if (res != 0) return;
            String oldPw = new String(oldP.getPassword()).trim();
            String newPw = new String(newP.getPassword()).trim();
            String con2  = new String(newP2.getPassword()).trim();
            if (oldPw.isEmpty()||newPw.isEmpty()) { JOptionPane.showMessageDialog(this,"⚠  All fields are required."); return; }
            if (!newPw.equals(con2)) { JOptionPane.showMessageDialog(this,"⚠  New passwords do not match."); return; }
            if (newPw.length()<6)    { JOptionPane.showMessageDialog(this,"⚠  Password must be at least 6 characters."); return; }

            new SwingWorker<Integer,Void>() {
                // 0=ok, 1=wrong old, 2=db error
                int status = 0; String errMsg = null;
                @Override protected Integer doInBackground() {
                    try {
                        java.sql.Connection conn = DBConnection.getInstance().getConnection();
                        // Verify current password
                        try (PreparedStatement ps = conn.prepareStatement(
                            "SELECT id FROM users WHERE id=? AND password_hash=?")) {
                            ps.setInt(1,u.getId()); ps.setString(2,oldPw);
                            try (java.sql.ResultSet rs = ps.executeQuery()) {
                                if (!rs.next()) { status=1; return 1; }
                            }
                        }
                        // Update
                        try (PreparedStatement ps = conn.prepareStatement(
                            "UPDATE users SET password_hash=? WHERE id=?")) {
                            ps.setString(1,newPw); ps.setInt(2,u.getId());
                            ps.executeUpdate();
                        }
                        return 0;
                    } catch(Exception ex){ errMsg=ex.getMessage(); status=2; return 2; }
                }
                @Override protected void done() {
                    try {
                        switch(get()) {
                            case 0 -> JOptionPane.showMessageDialog(SettingsPanel.this,
                                "✅  Password changed successfully!","Success",JOptionPane.INFORMATION_MESSAGE);
                            case 1 -> JOptionPane.showMessageDialog(SettingsPanel.this,
                                "❌  Current password is incorrect.","Error",JOptionPane.ERROR_MESSAGE);
                            default -> JOptionPane.showMessageDialog(SettingsPanel.this,
                                "❌  DB Error: "+errMsg,"Error",JOptionPane.ERROR_MESSAGE);
                        }
                    } catch(Exception ex){ ex.printStackTrace(); }
                }
            }.execute();
        }

        private JTextField styledField(String val) {
            JTextField f = new JTextField(val);
            f.setFont(new Font("Trebuchet MS",Font.PLAIN,13));
            f.setBackground(Color.WHITE); f.setForeground(CHARCOAL); f.setCaretColor(TEAL);
            f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200,228,224),1), new EmptyBorder(10,12,10,12)));
            f.setMaximumSize(new Dimension(Integer.MAX_VALUE,46));
            f.setAlignmentX(Component.LEFT_ALIGNMENT);
            f.addFocusListener(new FocusAdapter(){
                public void focusGained(FocusEvent e){f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(TEAL,2),new EmptyBorder(9,11,9,11)));}
                public void focusLost(FocusEvent e){f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(200,228,224),1),new EmptyBorder(10,12,10,12)));}
            });
            return f;
        }

        private JPasswordField styledPassField() {
            JPasswordField f = new JPasswordField();
            f.setFont(new Font("Trebuchet MS",Font.PLAIN,13));
            f.setBackground(Color.WHITE); f.setForeground(CHARCOAL); f.setCaretColor(TEAL);
            f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200,228,224),1), new EmptyBorder(10,12,10,12)));
            f.setMaximumSize(new Dimension(Integer.MAX_VALUE,46));
            f.setAlignmentX(Component.LEFT_ALIGNMENT);
            f.addFocusListener(new FocusAdapter(){
                public void focusGained(FocusEvent e){f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(TEAL,2),new EmptyBorder(9,11,9,11)));}
                public void focusLost(FocusEvent e){f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(200,228,224),1),new EmptyBorder(10,12,10,12)));}
            });
            return f;
        }

        private JLabel fLbl(String t) {
            JLabel l=new JLabel(t); l.setFont(new Font("Trebuchet MS",Font.BOLD,9));
            l.setForeground(WARM_GRAY); l.setAlignmentX(Component.LEFT_ALIGNMENT); return l;
        }
    }

}
